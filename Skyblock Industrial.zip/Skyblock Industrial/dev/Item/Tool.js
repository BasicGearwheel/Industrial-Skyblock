IDRegistry.genItemID( "Iron_Crook" );
Item.createItem( "Iron_Crook" , "Iron Crook" , { name : "Iron_Crook" } , { stack : 1 } );

IDRegistry.genItemID( "Diamond_Crook" );
Item.createItem( "Diamond_Crook" , "Diamond Crook" , { name : "Diamond_Crook" } , { stack : 1 } );

IDRegistry.genItemID( "Picking_Tool" );
Item.createItem( "Picking_Tool" , "Picking Tool" , { name : "Picking_Tool" } , { stack : 1 } );


Item.setToolRender( "Iron_Crook" , true );
Item.setToolRender( "Diamond_Crook" , true );
Item.setToolRender( "Picking_Tool" , true );

ToolAPI.registerTool( ItemID[ "Iron_Crook" ] , { durability : 250 } , [] , {
    calcDestroyTime : function ( tool , coords , block , timeData , defaultTime , enchantData ) {
        if ( block.id == VanillaTileID[ "leaves" ] || block.id == VanillaTileID[ "leaves2" ] ) return 0.2;
        return defaultTime;
    } ,
    onDestroy : function ( item , coords , block , player ) {
        if ( Game.getGameMode( ) == 1 ) {
            return false;
        }
    }
});


ToolAPI.registerTool( ItemID[ "Diamond_Crook" ] , { durability : 1561 } , [] , {
    calcDestroyTime : function ( tool , coords , block , timeData , defaultTime , enchantData ) {
        if ( block.id == VanillaTileID[ "leaves" ] || block.id == VanillaTileID[ "leaves2" ] ) return 0.2;
        return defaultTime;
    } ,
    onDestroy : function ( item , coords , block , player ) {
        if ( Game.getGameMode( ) == 1 ) {
            return false;
        }
    }
});

ToolAPI.registerTool( ItemID[ "Picking_Tool" ] , { durability : 152 } , [] , {
    calcDestroyTime : function ( tool , coords , block , timeData , defaultTime , enchantData ) {
        if ( block.id == VanillaTileID[ "leaves" ] || block.id == VanillaTileID[ "leaves2" ] ) return 0.4;
        return defaultTime;
    } ,
    onDestroy : function ( item , coords , block , player ) {
        if ( Game.getGameMode( ) == 1 ) {
            if ( block.id = 18 && block.data == ( 0 || 4 || 8 || 12 ) ) {
                Math.random() > 0.18 && World.drop( coords.x , coords.y , coords.z , ItemID[ "Pine_Nut" ] , 1 , 0 );
                Math.random() > 0.6 && World.drop( coords.x , coords.y , coords.z , ItemID[ "Green_Apple" ] , 1 , 0 );
                Math.random() > 0.75 && World.drop( coords.x , coords.y , coords.z , VanillaItemID[ "apple" ] , 1 , 0 );
            }
            return false;
        }
    }
});

ModAPI.addAPICallback( "ICore" , function ( api ) {
    IDRegistry.genItemID( "Iron_Treetap" );
    Item.createItem( "Iron_Treetap" , "Iron Treetap" , { name : "Iron_Treetap" } , { stack : 1 } );
    
    Item.setToolRender( "Iron_Treetap" , true );
    
    Item.registerUseFunction( ItemID[ "Iron_Treetap" ]  , function ( coords , item , block , player ) {
        if ( block.id == BlockID[ "rubberTreeLogLatex" ] ) {
            new PlayerActor( player ).addItemToInventory( ItemID[ "latex" ] , 1 , 0 );
        }
    } );
} );