IDRegistry.genItemID( "Iron_Stick" );
Item.createItem( "Iron_Stick" , "Iron Stick" , { name : "Iron_Stick" } );

IDRegistry.genItemID( "Motor" );
Item.createItem( "Motor" , "Motor" , { name : "Motor" } );

IDRegistry.genItemID( "Magnet_Ingot" );
Item.createItem( "Magnet_Ingot" , "Magnet Ingot" , { name : "Magnet_Ingot" } );

IDRegistry.genItemID( "Photosensitive_Element" );
Item.createItem( "Photosensitive_Element" , "Photosensitive Element" , { name : "Photosensitive_Element" } );

IDRegistry.genItemID( "Ceramics" );
Item.createItem( "Ceramics" , "Ceramics" , { name : "Ceramics" } );

IDRegistry.genItemID( "Heat_Resistant_Ceramics" );
Item.createItem( "Heat_Resistant_Ceramics" , "Heat Resistant Ceramics" , { name : "Heat_Resistant_Ceramics" } );


Recipes.addShaped( { id : ItemID[ "Iron_Stick" ] , count : 4 , data : 0 } ,
  [ "a " , " a"] ,
[ 'a' , VanillaItemID[ "iron_ingot" ] , 0 ] 
);

Recipes.addShaped( { id : ItemID[ "Magnet_Ingot" ] , count : 1 , data : 0 } ,
  [ "a " , " b"] ,
[ 'a' , VanillaItemID[ "iron_ingot" ] , 0 , "b" , ItemID[ "Iron_Stick" ] , 0 ] ,
  function ( api , result , player ) { new PlayerActor( player ).addItemToInventory( ItemID[ "Iron_Stick" ] , 1 , 0 ); } 
);

Recipes.addShaped( { id : ItemID[ "Photosensitive_Element" ] , count : 4 , data : 0 } ,
  [ " a " , "bc"] ,
[ 'a' , VanillaItemID[ "coal" ] , 0 , 'b' , ItemID[ "Ceramics" ] , 0 , 'c' , ItemID[ "ingotCopper" ] , 0 ] 
);
