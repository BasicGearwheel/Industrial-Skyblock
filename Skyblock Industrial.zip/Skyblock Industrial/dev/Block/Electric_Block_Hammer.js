var Windows_Width = 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 )

IDRegistry.genBlockID( "IS_Electric_Block_Hammer" );
Block.createBlock( "IS_Electric_Block_Hammer" , [
    { name : "Electric Block Hammer" , texture : [ [ "iron_block" , 0 ] , [ "iron_block" , 0 ] , [ "iron_block" , 0 ] ] , inCreative : true } ,
] , "Machine" );

var Block_Hammer = GetClassicUI( true );
Block_Hammer.drawing.push(
    { type : "text" , x : 225 , y : 60 , width : 230 , height : 46 , text : "Electric Block Hammer" , font : { size : 42 , color : "#FF4F4F4F" } } 
);
Block_Hammer.elements[ "Rate_Scale" ] = { type : "scale" , x : 100 , y : 75 , direction : 0 , bitmap : "Rate_Scale_Full" , scale : 10 };
for ( var i = 0 ; i < 9 ; i ++ ) {
    Block_Hammer.elements[ "Output_Slot" + i ] = { type: "slot" , x : 510 + ( i % 3 ) * 100 , y : 110 + ( i / 3 | 0 ) * 100 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { return false; } };
}
var Block_Hammer_MainUI = new UI.Window( Block_Hammer );

var Block_Hammer_Input = new UI.Window( {
    location : {
        x : ( 500 - 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 ) / 2 ) - 150 * Display_Unit  ,
        y : ( 500 * ( Height / Width ) - Window_Height * ( 1 + GUI_Scale * 0.2 ) / 2 ) - 100 * Display_Unit ,
        width : Windows_Width + 150 * Display_Unit  ,
        height : 100 * Display_Unit
    } ,
    
    drawing : [
        { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
        { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 100 * Display_Unit / Windows_Width + 150 * Display_Unit , bitmap : "Classic_Frame" , scale : 3 } ,
        { type : "text" , text : "Input" , x : 2 , y : 10 , font : { size : 50 } }
    ] ,
    elements : {}
} );

var Block_Hammer_Output = new UI.Window( {
    location : {
        x : ( 500 - 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 ) / 2 ) - 150 * Display_Unit  ,
        y : Window_Height * ( 1 + GUI_Scale * 0.2 ) + Window_Height * ( 1 + GUI_Scale * 0.2 ) ,
        width : Windows_Width + 150 * Display_Unit  ,
        height : 100 * Display_Unit
    } ,
    
    drawing : [
        { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
        { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 100 * Display_Unit / Windows_Width + 150 * Display_Unit , bitmap : "Classic_Frame" , scale : 3 } ,
        { type : "text" , text : "Output" , x : 2 , y : 10 , font : { size : 40 } }
    ] ,
    elements : {}
} );

var Block_Hammer_UI = new UI.WindowGroup();
Block_Hammer_MainUI.setInventoryNeeded( true );
Block_Hammer_UI.addWindowInstance( "Input" , Block_Hammer_Input );
Block_Hammer_UI.addWindowInstance( "Output" , Block_Hammer_Output );
Block_Hammer_UI.addWindowInstance( "Main" , Block_Hammer_MainUI );
Block_Hammer_UI.setBlockingBackground( true );



ICRender.getGroup( "ic-wire" ).add( BlockID[ "IS_Electric_Block_Hammer" ] , 0 );

TileEntity.registerPrototype( BlockID[ "IS_Electric_Block_Hammer" ] , {
    defaultValues : {
        "AddToMachine" : true ,
        "Scale" : 0 ,
        "FINISHIED_TIME" : 40 , 
        "ENERGY_USE" : 12 ,
        "IfEnergy" : 0 ,
        "TargetSide" : 0 ,
        "TargetBlock" : []
    } ,
    getGuiScreen : function () {
        return Block_Hammer_UI;
    } ,
    CanAddItem : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( item.id != id || item.data != data ) continue;
            Count -= Item.getMaxStack( id ) - item.count;
        }
        if ( Count <= 0 ) return true;
        if ( Count > 0 ) return false;
    } ,
    AddToMachine : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( ( ( item.id != id || item.data != data ) && item.id != 0 ) || Item.getMaxStack( id ) <= item.count || Count <= 0 ) continue;
            if ( item.id != 0 && item.data != data ) continue;
            if ( Item.getMaxStack( id ) > item.count + Count ) {
                this.container.setSlot( "Output_Slot" + i , id , item.count + Count , data );
                Count = 0;
                return;
            } else {
                let a = Item.getMaxStack( id ) - item.count;
                this.container.setSlot( "Output_Slot" + i , id , item.count + a , data );
                Count -= a;
            }
        }
        if ( Count > 0 ) World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , id , Count , data );
    } ,
    energyReceive : function ( type , amount , voltage ) {
        if ( this.data.IfEnergy < this.data.ENERGY_USE && amount >= this.data.ENERGY_USE ) {
            this.data.IfEnergy += this.data.ENERGY_USE ;
            return this.data.ENERGY_USE;
        }
        return 0;
    } ,
    getTarget : function ( ID ) {
        return World.getBlock( this.x + Side[ID][0] , this.y + Side[ID][1] , this.z + Side[ID][2] );
    } ,
    energyTick : function ( type , src ) { 
        if ( ExAPI.GetHammerDrops( this.getTarget.id , this.getTarget.data ) == ( null || undefined ) ) { return; }
        let target = ExAPI.GetHammerDrops( this.getTarget.id , this.getTarget.data );
        if ( this.data.AddToMachine == true ) {
            if ( this.CanAddItem( target.id , target.data , target.count ) == false ) {
                return;
            }
        }
        
        if ( this.data.IfEnergy >= this.data.ENERGY_USE ) {
            if ( this.data.Scale > 0 ){
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
                if ( this.data.TargetBlock.id != target.id || this.data.TargetBlock.data != target.data ) { this.data.Scale = 0 }
            } else if ( this.data.Scale == 0 ) {
                item.count --;
                this.data.TargetBlock = [ target.id , target.data ];
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
            }
        }
        
        if ( this.data.Scale == this.data.FINISHIED_TIME ) {
            if ( this.data.AddToMachine == true ) {
                this.AddToMachine( target.id , target.data , target.count );
            } else {
                World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , target.id , target.count , target.data );
            }
            this.data.Scale = 0;
            this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
        }
        this.container.validateAll();
    } ,
    canReceiveEnergy : function () { return true; }
} );
EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Electric_Block_Hammer" ] , EU );