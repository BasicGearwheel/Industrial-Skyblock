IMPORT( "EnergyNet" );
IMPORT( "OreDictionary" );
IMPORT( "ExAPI" );

var Display = UI.getContext().getWindowManager().getDefaultDisplay();
var Width = Display.getWidth();
var Height = Display.getHeight();
var EU = EnergyTypeRegistry.assureEnergyType( "Eu" , 1 );
var Settings = FileTools.ReadKeyValueFile( "/storage/emulated/0/games/horizon/minecraftpe/options.txt" );
var GUI_Scale = 0;
var Display_Unit = 1;
var Side = [ 
    [ 0 , -1 , 0 ] ,
    [ 1 , 0 , 0 ]  ,
    [ 0 , 0 , -1 ]  ,
    [ 0 , 0 , 1 ]  ,
    [ 0 , 1 , 0 ]  ,
    [ -1 , 0 , 0 ]
]

if ( Width > Height ) Display_Unit = ( Height / 1000 ) / ( Width / Height );
if ( Height > Width ) Display_Unit = ( Width / 1000 ) / ( Height / Width );
var Window_Height = 750 * Display_Unit;
/*
for ( let i in Settings ) {
    if ( i = "gfx_guiscale_offset" ) GUI_Scale = Settings[i];
    break;
}*/


function GetClassicUI ( inv , windowObj ) {
    var StandardClassicUI = {
        location : {
            x : 0 ,
            y : 0 ,
            width : 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 ) ,
            height : Window_Height * ( 1 + GUI_Scale * 0.2 )
        } ,
        
        drawing : [
            { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
            { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 952 , bitmap : "Classic_Frame" , scale : 5 }
        ] ,
        elements : {
            "Close1" : { type : "closeButton" , bitmap : "Close_off" , bitmap2 : "Close_on" , x : 895 , y : 20 , scale : 6 }
        }
    };
    if ( windowObj && windowObj.x ) StandardClassicUI.location.x = windowObj.x;
    if ( windowObj && windowObj.y ) StandardClassicUI.location.y = windowObj.y;
    if ( !windowObj || !windowObj.x ) StandardClassicUI.location.x = 500 - StandardClassicUI.location.width / 2;
    if ( !windowObj || !windowObj.y ) StandardClassicUI.location.y = 500 * ( Height / Width ) - StandardClassicUI.location.height / 2;
    if ( windowObj && windowObj.width ) StandardClassicUI.location.width = windowObj.width;
    if ( windowObj && windowObj.height ) StandardClassicUI.location.height = windowObj.height;
    
    if ( inv == true ) {
        StandardClassicUI.drawing.push( 
            { type : "text" , x : 42 , y : 480 , width : 150 , text : "Inventory" , height : 50 , font : { size : 50 } }
        );
        for ( var i = 9 ; i <= 44 ; i++ ) {
            StandardClassicUI.elements[ "InvSlot" + i ] = {
                type : "invSlot" , 
                x : 41 + ( i % 9 ) * 102 , 
                y : 498 + ( i / 9 | 0 ) * 102 - 102 , 
                size : 102 , 
                index : i 
            }
            if (  i >= 36 ) StandardClassicUI.elements[ "InvSlot" + i ].y = 490 + 17 + ( i / 9 | 0 ) * 102 - 102;
        };
    }
    return StandardClassicUI;
};

function GetClassicSpecialUI ( x , y , width , height , inv) {
    var UI = {
        location : { 
            x : x * Display_Unit ,
            y : y * Display_Unit ,
            width : width * Display_Unit * ( 1 + GUI_Scale * 0.2 ),
            height : height * Display_Unit
        } ,
        
        drawing : [
            { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
            { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 1000 , bitmap : "Classic_Frame" , scale : 4 }
        ]
    };
    if ( inv == true ) {
        StandardClassicUI.drawing.push( 
            { type : "text" , x : 42 , y : 480 , width : 150 , text : "Inventory" , height : 50 , font : { size : 50 } }
        );
        for ( var i = 9 ; i <= 44 ; i++ ) {
            StandardClassicUI.elements[ "InvSlot" + i ] = {
                type : "invSlot" , 
                x : 41 + ( i % 9 ) * 102 , 
                y : 498 + ( i / 9 | 0 ) * 102 - 102 , 
                size : 102 , 
                index : i 
            }
            if (  i >= 36 ) StandardClassicUI.elements[ "InvSlot" + i ].y = 490 + 17 + ( i / 9 | 0 ) * 102 - 102;
        };
    }
    return UI;
};

Block.createSpecialType( {
    base : VanillaBlockID[ "iron_block" ] ,
    solid : true ,
    destroytime : 0.8 ,
    explosionres : 15 ,
    lightopacity : 12 ,
    translucency : 1 
} , "Machine" );

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "dirt" ] , 0 , 
    [ [ ItemID[ "ex_stoneSmall" ] , 0 , 2 , 1 , true ] ,
    [ ItemID[ "ex_stoneSmall" ] , 0 , 2 , 0.5 , true ] ,
    [ ItemID[ "ex_stoneSmall" ] , 0 , 2 , 0.1 , true ] ,
    [ VanillaItemID[ "wheat_seeds" ] , 0 , 1 , 0.7 , true ] ,
    [ VanillaItemID[ "pumpkin_seeds" ] , 0 , 1 , 0.35 , true ] ,
    [ VanillaItemID[ "melon_seeds" ] , 0 , 1 , 0.35 , true ] ,
    [ ItemID[ "ex_seedsGrass" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsOak" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "melon_seeds" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsBamboo" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsCactus" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsCanes" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_spores" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsCarrot" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsPotato" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsBerries" ] , 0 , 1 , 0.05 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "gravel" ] , 0 , 
    [ [ VanillaItemID[ "flint" ] , 0 , 2 , 0.25 , true ] ,
    [ VanillaItemID[ "coal" ] , 0 , 1 , 0.125 , true ] ,
    [ VanillaItemID[ "lapis_lazuli" ] , 0 , 1 , 0.05 , true ] ,
    [ VanillaItemID[ "diamond" ] , 0 , 1 , 0.016 , true ] ,
    [ VanillaItemID[ "emerald" ] , 0 , 1 , 0.016 , true ] ,
    [ ItemID[ "ex_Tinbroken" ] , 0 , 1 , 0.18 , true ] ,
    [ ItemID[ "ex_Silverbroken" ] , 0 , 1 , 0.14 , true ] ,
    [ ItemID[ "ex_Leadbroken" ] , 0 , 1 , 0.15 , true ] ,
    [ ItemID[ "ex_Copperbroken" ] , 0 , 1 , 0.20 , true ] ,
    [ ItemID[ "ex_Ironbroken" ] , 0 , 1 , 0.25 , true ] ,
    [ ItemID[ "ex_Goldbroken" ] , 0 , 1 , 0.15 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 0 , 
    [ [ VanillaItemID[ "sapling" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 1 , 
    [ [ VanillaItemID[ "sapling" ] , 1 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 2 , 
    [ [ VanillaItemID[ "sapling" ] , 2 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 3 , 
    [ [ VanillaItemID[ "sapling" ] , 3 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 4 , 
    [ [ VanillaItemID[ "sapling" ] , 4 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves2" ] , 0 , 
    [ [ VanillaItemID[ "sapling" ] , 5 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves2" ] , 1 , 
    [ [ VanillaItemID[ "sapling" ] , 6 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( BlockID[ "ex_dust" ] , 0 , 
    [ [ VanillaItemID[ "glowstone_dust" ] , 0 , 1 , 0.07 , true ] ,
    [ VanillaItemID[ "redstone" ] , 0 , 1 , 0.25 , true ] ,
    [ VanillaItemID[ "gunpowder" ] , 0 , 1 , 0.0625 , true ] ,
    [ VanillaItemID[ "bone_meal" ] , 0 , 1 , 0.2 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "soul_sand" ] , 0 , 
    [ [ VanillaItemID[ "ghast_tear" ] , 0 , 1 , 0.02 , true ] ,
    [ VanillaItemID[ "quartz" ] , 0 , 1 , 1 , true ] ,
    [ VanillaItemID[ "quartz" ] , 0 , 1 , 0.8 , true ] ,
    [ VanillaItemID[ "soul_sand" ] , 0 , 1 , 0.1 , true ] ] 
);

ExAPI.SetBlockSieveDrops( BlockID[ "ex_gravelNether" ] , 0 , 
    [ [ ItemID[ "ex_Goldbroken" ] , 0 , 1 , 0.25 , true ] ,
    [ ItemID[ "ex_Goldbroken" ] , 0 , 1 , 0.4 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "sand" ] , 0 , 
    [ [ VanillaItemID[ "cocoa_beans" ] , 0 , 1 , 0.03 , true ] ,
    [ ItemID[ "ex_Ironbroken" ] , 0 , 1 , 0.5 , true ] ,
    [ VanillaItemID[ "prismarine_shard" ] , 0 , 1 , 0.02 , true ]  ]
);