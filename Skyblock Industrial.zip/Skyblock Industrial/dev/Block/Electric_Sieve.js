IDRegistry.genBlockID( "IS_Electric_Sieve" );
Block.createBlock( "IS_Electric_Sieve" , [
    { name : "Electric Sieve" , texture : [ [ "Electric_Sieve_buttom" , 0 ] , [ "Electric_Sieve_top" , 0 ] , [ "Electric_Sieve_outside" , 0 ] ] , inCreative : true } ,
] , "Machine" );

/*
var Model = new BlockRenderer.Model();
var MachineRender = new ICRender.Model();
Model.addBox( 0 , 0 , 0 , 1/16 , 10/16 , 1/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
Model.addBox( 1 , 0 , 0 , 15/16 , 10/16 , 1/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
Model.addBox( 0 , 0 , 1 , 1/16 , 10/16 , 15/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
Model.addBox( 1 , 0 , 1 , 15/16 , 10/16 , 15/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
MachineRender.addEntry( Model );
BlockRenderer.setStaticICRender( BlockID[ "IS_Electric_Sieve" ] , 0  , MachineRender );
*/

var Electric_Sieve = GetClassicUI( true );
Electric_Sieve.drawing.push(
    { type : "text" , x : 360 , y : 60 , width : 230 , height : 46 , text : "Electric Sieve" , font : { size : 42 , color : "#FF4F4F4F" } } 
);
Electric_Sieve.elements[ "Empty_Rate_Scale" ] = { type: "image" , x : 390 , y : 170 , direction : 0 , bitmap : "Rate_Scale" , scale : 6.5 };
Electric_Sieve.elements[ "Rate_Scale" ] = { type: "scale" , x : 390 , y : 170 , direction : 0 , bitmap : "Rate_Scale_Full" , scale : 6.5 };
Electric_Sieve.elements[ "Input_Slot" ] = { type: "slot" , x : 215 , y : 160 , size : 125 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) {
    if ( ExAPI.GetSieveDrops( id , data ) != ( null || undefined ) ) return true;
    return false;
} };
Electric_Sieve.elements[ "Drop_Point" ] = { type: "button" , x : 240 , y :50 , scale : 3 , bitmap : "AddInside_Button" , bitmap2 : "AddInside_Button_Press" , clicker : { 
    onClick : function ( position , container , tileEntity , window , canvas , scale ) {
        var ThisObj = container.getGuiContent().elements[ "Drop_Point" ];
        if ( ThisObj.bitmap == "AddInside_Button" ) {
            ThisObj.bitmap = "AddOutside_Button";
            ThisObj.bitmap2 = "AddOutside_Button_Press";
            tileEntity.data.AddToMachine = false;
        } else {
            ThisObj.bitmap = "AddInside_Button";
            ThisObj.bitmap2 = "AddInside_Button_Press";
            tileEntity.data.AddToMachine = true;
        }
    }
} };
for ( var i = 0 ; i < 9 ; i ++ ) {
    Electric_Sieve.elements[ "Output_Slot" + i ] = { type: "slot" , x : 510 + ( i % 3 ) * 100 , y : 110 + ( i / 3 | 0 ) * 100 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { return false; } };
}
var Sieve_UI = new UI.Window( Electric_Sieve );
Sieve_UI.setInventoryNeeded( true );
Sieve_UI.setBlockingBackground( true );

ICRender.getGroup( "ic-wire" ).add( BlockID[ "IS_Electric_Sieve" ] , 0 );

TileEntity.registerPrototype( BlockID[ "IS_Electric_Sieve" ] , {
    defaultValues : {
        "AddToMachine" : true ,
        "Scale" : 0 ,
        "DropingList" : [] ,
        "FINISHIED_TIME" : 40 , 
        "ENERGY_USE" : 10 ,
        "IfEnergy" : 0
    } ,
    getGuiScreen : function () {
        return Sieve_UI;
    } ,
    CanAddItem : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( item.id != id || item.data != data ) continue;
            Count -= Item.getMaxStack( id ) - item.count;
        }
        if ( Count <= 0 ) return true;
        if ( Count > 0 ) return false;
    } ,
    AddToMachine : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( ( ( item.id != id || item.data != data ) && item.id != 0 ) || Item.getMaxStack( id ) <= item.count || Count <= 0 ) continue;
            if ( item.id != 0 && item.data != data ) continue;
            if ( Item.getMaxStack( id ) > item.count + Count ) {
                this.container.setSlot( "Output_Slot" + i , id , item.count + Count , data );
                Count = 0;
                return;
            } else {
                let a = Item.getMaxStack( id ) - item.count;
                this.container.setSlot( "Output_Slot" + i , id , item.count + a , data );
                Count -= a;
            }
        }
        if ( Count > 0 ) World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , id , Count , data );
    } ,
    energyReceive : function ( type , amount , voltage ) {
        if ( this.data.IfEnergy < this.data.ENERGY_USE && amount >= this.data.ENERGY_USE ) {
            this.data.IfEnergy += this.data.ENERGY_USE ;
            return this.data.ENERGY_USE;
        }
        return 0;
    } ,
    energyTick : function ( type , src ) {
        if ( this.data.AddToMachine == true ) {
            let SieveDrop = ExAPI.GetSieveDrops( this.container.getSlot( "Input_Slot" ).id , this.container.getSlot( "Input_Slot" ).data );
            for ( i in SieveDrop ) {
                if ( this.CanAddItem( SieveDrop , SieveDrop , 1 ) == false ) {
                    return;
                }
            }
        }
        
        let item = this.container.getSlot( "Input_Slot" );
        if ( this.data.IfEnergy >= 5 ) {
            if ( this.data.Scale > 0 ){
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
            } else if ( this.container.getSlot( "Input_Slot" ).count > 0 ) {
                item.count --;
                this.data.DropingList = ExAPI.GetFiltering( item.id , item.data );
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
            }
        }
        
        if ( this.data.Scale == this.data.FINISHIED_TIME ) {
            for ( var i in this.data.DropingList ) {
                let List = this.data.DropingList[ i ];
                if ( this.data.AddToMachine == true ) {
                    this.AddToMachine( List[0] , List[1] , List[2] );
                } else {
                    World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , List[0] , List[2] , List[1] );
                }
            }
            this.data.Scale = 0;
            this.data.DropingList = [];
            this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
        }
        this.container.validateAll();
    } ,
    canReceiveEnergy : function () { return true; }
} );
EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Electric_Sieve" ] , EU );