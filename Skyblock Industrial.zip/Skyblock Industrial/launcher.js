ConfigureMultiplayer( {
    name: "Industrial Skyblock" ,
    version: "0.0001" ,
    isClientOnly: false
} );
ModAPI.addAPICallback( "ENR" , function ( api ) {
    Launch();
} );