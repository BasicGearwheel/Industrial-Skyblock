IDRegistry.genBlockID( "IS_Solor" );
Block.createBlock( "IS_Solor" , [
    { name : "Solor" , texture : [ [ "Solor_buttom" , 0 ] , [ "Solor_top" , 0 ] , [ "Solor_side" , 0 ] ] , inCreative : true } 
] , "Machine" );
Block.setShape( BlockID[ "IS_Solor" ] , 0 , 0 , 0 , 1 , 1/16 , 1 , 0 );

TileEntity.registerPrototype( BlockID[ "IS_Solor" ] , {
    isEnergySource : function () {
        return true;
    } ,
    canReceiveEnergy : function () {
        return false;
    } ,
    energyTick : function( type, src ) {
        let Light_Level = new BlockSource( EDimension[ "NORMAL" ] ).getLightLevel( this.x , this.y + 1 , this.z );
        src.addAll( Math.round( Light_Level / 2 ) );
    } ,
    canExtractEnergy : function ( side, type )  {
        if ( side == EBlockSide[ "DOWN" ] ) return true;
        return false;
    }
});

EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Solor" ] , EU );


IDRegistry.genBlockID( "IS_Lava_Generator" );
Block.createBlock( "IS_Lava_Generator" , [
    { name : "Lava Generator" , texture : [ [ "Lava_Generator_side" , 0 ] , [ "Lava_Generator_top" , 0 ] , [ "Lava_Generator_side" , 0 ] ] , inCreative : true } ,
    { name : "Lava Generator" , texture : [ [ "Lava_Generator_side" , 0 ] , [ "Lava_Generator_top_anim" , 0 ] , [ "Lava_Generator_side" , 0 ] ] , inCreative : false }
] , "Machine" );

/*
var Model = new BlockRenderer.Model();
var MachineRender = new ICRender.Model();
Model.addBox( 0 , 0 , 0 , 1 , 1 , 1 , BlockID[ "IS_Lava_Generator" ] , 1 );
MachineRender.addEntry( Model );
BlockRenderer.enableCoordMapping( BlockID[ "IS_Lava_Generator" ] , 0 , MachineRender );
*/

var LavaGenerator = GetClassicUI( true );
LavaGenerator.drawing.push(
    { type : "text" , x : 300 , y : 60 , width : 230 , height : 42 , text : "Lava Generator" , font : { size : 42 , color : "#FF4F4F4F" } } 
);
LavaGenerator.elements[ "Lava_Scale_Empty" ] = { type: "image" , x : 364 , y: 75 , direction : 1 , bitmap : "Liquid_Empty_Scale" , scale : 4.5 };
LavaGenerator.elements[ "Lava_Scale" ] = { type: "scale" , x : 364 , y: 75 , direction : 1 , bitmap : "Full_Lava" , scale : 4.5 };
LavaGenerator.elements[ "Liquid_Slot" ] = { type: "slot" , x : 540 , y : 90 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { 
    if ( LiquidRegistry.getEmptyItem( id , data ) && LiquidRegistry.getEmptyItem( id , data ).liquid == "lava" ) return true;
    return false;
} };
LavaGenerator.elements[ "Empty_Slot" ] = { type: "slot" , x : 540 , y :290 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { return false } };
var Lava_UI = new UI.Window( LavaGenerator );
Lava_UI.setInventoryNeeded( true );
Lava_UI.setBlockingBackground( true );

TileEntity.registerPrototype( BlockID[ "IS_Lava_Generator" ] , {
    defaultValues : {
        "TickUse" : 0.01 ,
        "Max_Storge" : 10
    } ,
    getGuiScreen : function () {
        return Lava_UI;
    } ,
    isEnergySource : function () {
        return true;
    } ,
    canReceiveEnergy : function () {
        return false;
    } ,
    tick : function () {
        let Slot1 = this.container.getSlot( "Liquid_Slot" );
        let Slot2 = this.container.getSlot( "Empty_Slot" );
        if ( Slot1.id == 0 || this.liquidStorage.getAmount( "lava" ) > this.data.Max_Storge - 1 || Item.getMaxStack( Slot2.id ) <= Slot2.count ) return;
        let Slot1Empty = LiquidRegistry.getEmptyItem( Slot1.id , Slot1.data );
        if ( Slot1Empty == ( null || undefined ) ) return;
        if ( ( Slot1Empty.id != Slot2.id || Slot1Empty.data != Slot2.data ) && Slot2.id != 0 ) return;
        Slot1.count --;
        this.container.setSlot( "Empty_Slot" , Slot1Empty.id , Slot2.count + ( Slot1Empty.count || 1 ) , Slot1Empty.data );
        let lava_amount = this.liquidStorage.getAmount( "lava" );
        this.liquidStorage.setAmount( "lava" , lava_amount + 1 );
        this.container.validateAll();
    } ,
    energyTick : function ( type, src ) {
        let Lava_Amount = this.liquidStorage.getAmount( "lava" );
        if ( Lava_Amount >= this.data.TickUse ) {
            this.blockSource.setBlock( this.x , this.y , this.z , BlockID[ "IS_Lava_Generator" ] , 1 );
            src.addAll( 70 );
            this.liquidStorage.setAmount( "lava" , Lava_Amount - this.data.TickUse );
        } else if ( this.liquidStorage.getAmount( "lava" ) < this.data.TickUse && this.blockSource.getBlockData( this.x , this.y , this.z ) == 1 ) {
            this.blockSource.setBlock( this.x , this.y , this.z , BlockID[ "IS_Lava_Generator" ] , 0 );
        }
        this.container.setScale( "Lava_Scale" , this.liquidStorage.getAmount( "lava" ) / this.data.Max_Storge );
    } 
} );

EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Lava_Generator" ] , EU );


Recipes.addShaped( { id : BlockID[ "IS_Lava_Generator" ] , count : 1 , data : 0 } ,
  [ "aba" , "bcb" , "ada" ] ,
[ 'a' , VanillaItemID[ "iron_ingot" ] , 0 , 'b' , ItemID[ "Heat_Resistant_Ceramics" ] , 0 , 'c' , VanillaBlockID[ "furnace" ] , 0 , 'd' , VanillaItemID[ "bucket" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "IS_Solor" ] , count : 1 , data : 0 } ,
  [ "aaa" , "bcb" ] ,
[ 'a' , ItemID[ "Photosensitive_Element" ] , 0 , 'b' , VanillaItemID[ "iron_ingot" ] , 0 , 'c' , ItemID[ "ingotCopper" ] , 0 ] 
);