Block.createSpecialType( {
    base : VanillaBlockID[ "glass" ] ,
    solid : false ,
    destroytime : 0.3 ,
    explosionres : 0.3 ,
    lightopacity : 0 ,
    renderlayer : 4 ,
    translucency : 0.1 ,
    sound: "glass"
} , "CrystalGlass" );

IDRegistry.genBlockID( "Crystal_Glass" );
Block.createBlock( "Crystal_Glass" , [
    { name : "Crystal Glass" , texture : [ [ "Crystal_Glass" , 0 ] ] , inCreative : true } ,
] , "CrystalGlass" );

IDRegistry.genBlockID( "Crystal_Light_Glass " );
Block.createBlock( "Crystal_Light_Glass " , [
    { name : "Crystal Light Glass" , texture : [ [ "Crystal_Light_Glass" , 0 ] ] , inCreative : true } ,
] , Block.createSpecialType( {
    base : VanillaBlockID[ "glass" ] ,
    solid : false ,
    destroytime : 0.3 ,
    explosionres : 0.3 ,
    lightopacity : 0 ,
    lightlevel : 14 ,
    translucency : 0.1 ,
    sound: "glass"
} ) );

IDRegistry.genBlockID( "CrystalGlass_Colorful" );
Block.createBlock( "CrystalGlass_Colorful" , [
    { name : "Black Crystal Glass" , texture : [ [ "CrystalGlass_Black" , 0 ] ] , inCreative : true } ,
    { name : "Gray Crystal Glass" , texture : [ [ "CrystalGlass_Gray" , 0 ] ] , inCreative : true } ,
    { name : "Blue Crystal Glass" , texture : [ [ "CrystalGlass_Blue" , 0 ] ] , inCreative : true } ,
    { name : "Light Blue Crystal Glass" , texture : [ [ "CrystalGlass_LightBlue" , 0 ] ] , inCreative : true } ,
    { name : "Yellow Crystal Glass" , texture : [ [ "CrystalGlass_Yellow" , 0 ] ] , inCreative : true } ,
    { name : "Pink Crystal Glass" , texture : [ [ "CrystalGlass_Pink" , 0 ] ] , inCreative : true } ,
    { name : "Orange Crystal Glass" , texture : [ [ "CrystalGlass_Orange" , 0 ] ] , inCreative : true } ,
    { name : "Lime Crystal Glass" , texture : [ [ "CrystalGlass_Lime" , 0 ] ] , inCreative : true } ,
    { name : "Cyan Crystal Glass" , texture : [ [ "CrystalGlass_Cyan" , 0 ] ] , inCreative : true } ,
    { name : "Brown Crystal Glass" , texture : [ [ "CrystalGlass_Brown" , 0 ] ] , inCreative : true } ,
    { name : "Green Crystal Glass" , texture : [ [ "CrystalGlass_Green" , 0 ] ] , inCreative : true } ,
    { name : "Purple Crystal Glass" , texture : [ [ "CrystalGlass_Purple" , 0 ] ] , inCreative : true } ,
    { name : "Red Crystal Glass" , texture : [ [ "CrystalGlass_Red" , 0 ] ] , inCreative : true } ,
    { name : "White Crystal Glass" , texture : [ [ "CrystalGlass_White" , 0 ] ] , inCreative : true } ,
    { name : "Magenta Crystal Glass" , texture : [ [ "CrystalGlass_Magenta" , 0 ] ] , inCreative : true } ,
    { name : "Light Gray Crystal Glass" , texture : [ [ "CrystalGlass_LightGray" , 0 ] ] , inCreative : true } ,
] , "CrystalGlass" );

IDRegistry.genBlockID( "Light_Rod" );
Block.createBlock( "Light_Rod" , [
    { name : "Light Rod" , texture : [ [ "LightRod_top" , 0 ] , [ "LightRod_top" , 0 ] , [ "Light_Rod" , 0 ] ] , inCreative : true } ,
] , Block.createSpecialType( {
    base : VanillaBlockID[ "end_rod" ] ,
    solid : false ,
    destroytime : 0.5 ,
    explosionres : 0.4 ,
    lightopacity : 8 ,
    lightlevel : 15 ,
    translucency : 0.1 ,
    sound: "glass"
} ) );

var RodModel = new BlockRenderer.Model();
var RodICRender = new ICRender.Model();
RodModel.addBox( 11/16 , 0 , 11/16 , 5/16 , 1/16 , 5/16 , BlockID[ "Light_Rod" ] , 0 );
RodModel.addBox( 6/16 , 1/16 , 6/16 , 10/16 , 2/16 , 10/16 , BlockID[ "Light_Rod" ] , 0 );
RodModel.addBox( 7/16 , 2/16 , 7/16 , 9/16 , 13/16 , 9/16 , BlockID[ "Light_Rod" ] , 0 );
RodICRender.addEntry( RodModel );
BlockRenderer.setStaticICRender( BlockID[ "Light_Rod" ] , 0 , RodICRender );
Block.setShape( BlockID[ "Light_Rod" ] , 5/16 , 0 , 5/16 , 11/16 , 13/16 , 11/16 , 0 );



var GlassVertex = [
    [ 0 , 0 , 0 , 1/16 , 1/16 , 1/16 ] ,
    [ 0 , 0 , 1 , 1/16 , 1/16 , 15/16 ] ,
    [ 1 , 0 , 1 , 15/16 , 1/16 , 15/16 ] ,
    [ 1 , 0 , 0 , 15/16 , 1/16 , 1/16 ] ,
    [ 0 , 1 , 0 , 1/16 , 15/16 , 1/16 ] ,
    [ 0 , 1 , 1 , 1/16 , 15/16 , 15/16 ] ,
    [ 1 , 1 , 1 , 15/16 , 15/16 , 15/16 ] ,
    [ 1 , 1 , 0 , 15/16 , 15/16 , 1/16 ] 
];

var GlassEdge = [
    [ 0 , 0 , 1/16 , 1/16 , 1/16 , 15/16 ] ,
    [ 1/16 , 0 , 1/16 , 15/16 , 1/16 , 0 ] ,
    [ 15/16 , 0 , 15/16 , 1 , 1/16 , 1/16 ] ,
    [ 15/16 , 0 , 15/16 , 1/16 , 1/16 , 1 ] ,
    [ 0 , 1 , 1/16 , 1/16 , 15/16 , 15/16 ] ,
    [ 1/16 , 1 , 1/16 , 15/16 , 15/16 , 0 ] ,
    [ 15/16 , 1 , 15/16 , 1 , 15/16 , 1/16 ] ,
    [ 15/16 , 1 , 15/16 , 1/16 , 15/16 , 1 ] ,
    [ 0 , 1/16 , 0 , 1/16 , 15/16 , 1/16 ] ,
    [ 1 , 1/16 , 0 , 15/16 , 15/16 , 1/16 ] ,
    [ 1 , 1/16 , 1 , 15/16 , 15/16 , 15/16 ] ,
    [ 0 , 1/16 , 1 , 1/16 , 15/16 , 15/16 ] 
];

var GlassSide = {
    Side1 : [ 1 , 0 , 0 ] ,
    Side2 : [ 0 , 1 , 0 ] ,
    Side3 : [ 0 , 0 , 1 ] ,
    Side4 : [ -1 , 0 , 0 ] ,
    Side5 : [ 0 , -1 , 0 ] ,
    Side6 : [ 0 , 0 , -1 ] 
};

var VertexGlassAngle = {
//Layer1
    An1 : [ [ 0 , -1 , 0 ] , [ -1 , -1 , 0 ] , [ -1 , 0 , 0 ] ] ,
    An2 : [ [ 0 , -1 , 0 ] , [ 0 , -1 , 1 ] , [ 0 , 0 , 1 ] ] ,
    An3 : [ [ 0 , -1 , 0 ] , [ 1 , -1 , 0 ] , [ 1 , 0 , 0 ] ] ,
    An4 : [ [ 0 , -1 , 0 ] , [ 0 , -1 , -1 ] , [ 0 , 0 , -1 ] ] ,
//Layer2
    An5 : [ [ 0 , 0 , -1 ] , [ -1 , 0 , -1 ] , [ -1 , 0 , 0 ] ] ,
    An6 : [ [ -1 , 0 , 0 ] , [ -1 , 0 , 1 ] , [ 0 , 0 , 1 ] ] ,
    An7 : [ [ 0 , 0 , 1 ] , [ 1 , 0 , 1 ] , [ 1 , 0 , 0 ] ] ,
    An8 : [ [ 1 , 0 , 0 ] , [ 1 , 0 , -1 ] , [ 0 , 0 , -1 ] ] ,
//Layer3
    An9 : [ [ 0 , 1 , 0 ] , [ -1 , 1 , 0 ] , [ -1 , 0 , 0 ] ] ,
    An10 : [ [ 0 , 1 , 0 ] , [ 0 , 1 , 1 ] , [ 0 , 0 , 1 ] ] ,
    An11 : [ [ 0 , 1 , 0 ] , [ 1 , 1 , 0 ] , [ 1 , 0 , 0 ] ] ,
    An12 : [ [ 0 , 1 , 0 ] , [ 0 , 1 , -1 ] , [ 0 , 0 , -1 ] ] 
};

var EdgeGlassCondition = [
    { Edge : 0 , Side : [ "Side4" , "Side5" ] } ,
    { Edge : 1 , Side : [ "Side5" , "Side6" ] } ,
    { Edge : 2 , Side : [ "Side1" , "Side5" ] } ,
    { Edge : 3 , Side : [ "Side3" , "Side5" ] } ,
    { Edge : 4 , Side : [ "Side2" , "Side4" ] } ,
    { Edge : 5 , Side : [ "Side2" , "Side6" ] } ,
    { Edge : 6 , Side : [ "Side1" , "Side2" ] } ,
    { Edge : 7 , Side : [ "Side2" , "Side3" ] } ,
    { Edge : 8 , Side : [ "Side4" , "Side6" ] } ,
    { Edge : 9 , Side : [ "Side1" , "Side6" ] } ,
    { Edge : 10 , Side : [ "Side1" , "Side3" ] } ,
    { Edge : 11 , Side : [ "Side3" , "Side4" ] } 
];

var VertexGlassCondition = [
    { Ver : 0 , Angle : [ "An1" , "An5" , "An4" ] } ,
    { Ver : 1 , Angle : [ "An1" , "An6" , "An2" ] } ,
    { Ver : 2 , Angle : [ "An2" , "An7" , "An3" ] } ,
    { Ver : 3 , Angle : [ "An3" , "An8" , "An4" ] } ,
    { Ver : 4 , Angle : [ "An9" , "An5" , "An12" ] } ,
    { Ver : 5 , Angle : [ "An9" , "An6" , "An10" ] } ,
    { Ver : 6 , Angle : [ "An10" , "An7" , "An11" ] } ,
    { Ver : 7 , Angle : [ "An11" , "An8" , "An12" ] }
];

var GlassGroup = ICRender.getUnnamedGroup();

function SetGlassBeautiful ( id , data ) {
    GlassGroup.add( id , data );
    let BlockModel = new BlockRenderer.Model();
    let ICRenderModel = new ICRender.Model();
    for ( var i in EdgeGlassCondition ) {
        let edge = EdgeGlassCondition[i].Edge;
        let side = EdgeGlassCondition[i].Side;
        ICRenderModel.addEntry( new BlockRenderer.Model( GlassEdge[edge][0] , GlassEdge[edge][1] , GlassEdge[edge][2] , GlassEdge[edge][3] , GlassEdge[edge][4] , GlassEdge[edge][5] , id , data ) )
        .setCondition( new ICRender.NOT( new ICRender.OR( ICRender.BLOCK( GlassSide[side[0]][0] , GlassSide[side[0]][1] , GlassSide[side[0]][2] , GlassGroup , false ) ,
        ICRender.BLOCK( GlassSide[side[1]][0] , GlassSide[side[1]][1] , GlassSide[side[1]][2] , GlassGroup , false ) ) ) );
    };
    for ( var i in VertexGlassCondition ) {
        let ver = GlassVertex[VertexGlassCondition[i].Ver];
        let ang1 = VertexGlassAngle[VertexGlassCondition[i].Angle[0]];
        let ang2 = VertexGlassAngle[VertexGlassCondition[i].Angle[1]];
        let ang3 = VertexGlassAngle[VertexGlassCondition[i].Angle[2]];
        var C1 = new ICRender.AND( new ICRender.BLOCK( ang1[0][0] , ang1[0][1] , ang1[0][2] , GlassGroup , false ) ,
                                   new ICRender.BLOCK( ang1[1][0] , ang1[1][1] , ang1[1][2] , GlassGroup , false ) , 
                                   new ICRender.BLOCK( ang1[2][0] , ang1[2][1] , ang1[2][2] , GlassGroup , false ) );
        var C2 = new ICRender.AND( new ICRender.BLOCK( ang2[0][0] , ang2[0][1] , ang2[0][2] , GlassGroup , false ) ,
                                   new ICRender.BLOCK( ang2[1][0] , ang2[1][1] , ang2[1][2] , GlassGroup , false ) , 
                                   new ICRender.BLOCK( ang2[2][0] , ang2[2][1] , ang2[2][2] , GlassGroup , false ) );
        var C3 = new ICRender.AND( new ICRender.BLOCK( ang3[0][0] , ang3[0][1] , ang3[0][2] , GlassGroup , false ) ,
                                   new ICRender.BLOCK( ang3[1][0] , ang3[1][1] , ang3[1][2] , GlassGroup , false ) , 
                                   new ICRender.BLOCK( ang3[2][0] , ang3[2][1] , ang3[2][2] , GlassGroup , false ) );
        ICRenderModel.addEntry( new BlockRenderer.Model( ver[0] , ver[1] , ver[2] , ver[3] , ver[4] , ver[5] , id , data ) )
        .setCondition( new ICRender.AND( new ICRender.NOT( C1 ) , new ICRender.NOT( C2 ) , new ICRender.NOT( C3 ) ) );
    };
    ICRenderModel.addEntry( BlockModel );
    BlockRenderer.setStaticICRender( id , data , ICRenderModel );
};

SetGlassBeautiful( BlockID[ "Crystal_Glass" ] , 0 );
SetGlassBeautiful( BlockID[ "Crystal_Light_Glass " ] , 0 );
for ( var i = 0 ; i <= 15 ; i ++ ) {
    SetGlassBeautiful( BlockID[ "CrystalGlass_Colorful" ] , i );
}

Recipes.addShaped( { id : BlockID[ "Light_Rod" ] , count : 1 , data : 0 } ,
  [ " a" , "aba" ] , 
[ 'a' , VanillaItemID[ "glowstone_dust" ] , 0 , 'b' , VanillaItemID[ "redstone" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "Crystal_Light_Glass " ] , count : 1 , data : 0 } ,
  [ " a" , "aba" , "a" ] , 
[ 'a' , VanillaItemID[ "glowstone_dust" ] , 0 , 'b' , BlockID[ "Crystal_Glass" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 0 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "black_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 1 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "gray_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 2 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "blue_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 3 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "light_blue_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 4 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "yellow_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 4 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "yellow_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 5 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "pink_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 6 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "orange_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 7 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "lime_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 8 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "cyan_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 9 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "brown_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 10 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "green_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 11 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "purple_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 12 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "red_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 13 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "white_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 14 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "magenta_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 15 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "light_gray_dye" ] , 0 ] 
);

Recipes.addFurnace( VanillaBlockID[ "glass" ] , 0 , BlockID[ "Crystal_Glass" ] , 0 );

Block.registerDropFunction( BlockID[ "Crystal_Glass" ] , function ( coords , id , data , diggingLevel , enchant , item , region ) {
    if ( enchant == EEnchantment[ "UNBREAKING" ] ) return [ [ id , 1 , data ] ];
    return [];
} );

Block.registerDropFunction( BlockID[ "CrystalGlass_Colorful" ] , function ( coords , id , data , diggingLevel , enchant , item , region ) {
    if ( enchant == EEnchantment[ "UNBREAKING" ] ) return [ [ id , 1 , data ] ];
    return [];
} );

Block.registerDropFunction( BlockID[ "Crystal_Light_Glass" ] , function ( coords , id , data , diggingLevel , enchant , item , region ) {
    if ( enchant == EEnchantment[ "UNBREAKING" ] ) return [ [ id , 1 , data ] ];
    return [];
} );