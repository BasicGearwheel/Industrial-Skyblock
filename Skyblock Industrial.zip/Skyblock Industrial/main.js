/*
BUILD INFO:
  dir: dev
  target: main.js
  files: 8
*/



// file: Preparing.js

IMPORT( "EnergyNet" );
IMPORT( "OreDictionary" );
IMPORT( "ExAPI" );

var Display = UI.getContext().getWindowManager().getDefaultDisplay();
var Width = Display.getWidth();
var Height = Display.getHeight();
var EU = EnergyTypeRegistry.assureEnergyType( "Eu" , 1 );
var Settings = FileTools.ReadKeyValueFile( "/storage/emulated/0/games/horizon/minecraftpe/options.txt" );
var GUI_Scale = 0;
var Display_Unit = 1;
var Side = [ 
    [ 0 , -1 , 0 ] ,
    [ 1 , 0 , 0 ]  ,
    [ 0 , 0 , -1 ]  ,
    [ 0 , 0 , 1 ]  ,
    [ 0 , 1 , 0 ]  ,
    [ -1 , 0 , 0 ]
]

if ( Width > Height ) Display_Unit = ( Height / 1000 ) / ( Width / Height );
if ( Height > Width ) Display_Unit = ( Width / 1000 ) / ( Height / Width );
var Window_Height = 750 * Display_Unit;
/*
for ( let i in Settings ) {
    if ( i = "gfx_guiscale_offset" ) GUI_Scale = Settings[i];
    break;
}*/


function GetClassicUI ( inv , windowObj ) {
    var StandardClassicUI = {
        location : {
            x : 0 ,
            y : 0 ,
            width : 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 ) ,
            height : Window_Height * ( 1 + GUI_Scale * 0.2 )
        } ,
        
        drawing : [
            { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
            { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 952 , bitmap : "Classic_Frame" , scale : 5 }
        ] ,
        elements : {
            "Close1" : { type : "closeButton" , bitmap : "Close_off" , bitmap2 : "Close_on" , x : 895 , y : 20 , scale : 6 }
        }
    };
    if ( windowObj && windowObj.x ) StandardClassicUI.location.x = windowObj.x;
    if ( windowObj && windowObj.y ) StandardClassicUI.location.y = windowObj.y;
    if ( !windowObj || !windowObj.x ) StandardClassicUI.location.x = 500 - StandardClassicUI.location.width / 2;
    if ( !windowObj || !windowObj.y ) StandardClassicUI.location.y = 500 * ( Height / Width ) - StandardClassicUI.location.height / 2;
    if ( windowObj && windowObj.width ) StandardClassicUI.location.width = windowObj.width;
    if ( windowObj && windowObj.height ) StandardClassicUI.location.height = windowObj.height;
    
    if ( inv == true ) {
        StandardClassicUI.drawing.push( 
            { type : "text" , x : 42 , y : 480 , width : 150 , text : "Inventory" , height : 50 , font : { size : 50 } }
        );
        for ( var i = 9 ; i <= 44 ; i++ ) {
            StandardClassicUI.elements[ "InvSlot" + i ] = {
                type : "invSlot" , 
                x : 41 + ( i % 9 ) * 102 , 
                y : 498 + ( i / 9 | 0 ) * 102 - 102 , 
                size : 102 , 
                index : i 
            }
            if (  i >= 36 ) StandardClassicUI.elements[ "InvSlot" + i ].y = 490 + 17 + ( i / 9 | 0 ) * 102 - 102;
        };
    }
    return StandardClassicUI;
};

function GetClassicSpecialUI ( x , y , width , height , inv) {
    var UI = {
        location : { 
            x : x * Display_Unit ,
            y : y * Display_Unit ,
            width : width * Display_Unit * ( 1 + GUI_Scale * 0.2 ),
            height : height * Display_Unit
        } ,
        
        drawing : [
            { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
            { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 1000 , bitmap : "Classic_Frame" , scale : 4 }
        ]
    };
    if ( inv == true ) {
        StandardClassicUI.drawing.push( 
            { type : "text" , x : 42 , y : 480 , width : 150 , text : "Inventory" , height : 50 , font : { size : 50 } }
        );
        for ( var i = 9 ; i <= 44 ; i++ ) {
            StandardClassicUI.elements[ "InvSlot" + i ] = {
                type : "invSlot" , 
                x : 41 + ( i % 9 ) * 102 , 
                y : 498 + ( i / 9 | 0 ) * 102 - 102 , 
                size : 102 , 
                index : i 
            }
            if (  i >= 36 ) StandardClassicUI.elements[ "InvSlot" + i ].y = 490 + 17 + ( i / 9 | 0 ) * 102 - 102;
        };
    }
    return UI;
};

Block.createSpecialType( {
    base : VanillaBlockID[ "iron_block" ] ,
    solid : true ,
    destroytime : 0.8 ,
    explosionres : 15 ,
    lightopacity : 12 ,
    translucency : 1 
} , "Machine" );

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "dirt" ] , 0 , 
    [ [ ItemID[ "ex_stoneSmall" ] , 0 , 2 , 1 , true ] ,
    [ ItemID[ "ex_stoneSmall" ] , 0 , 2 , 0.5 , true ] ,
    [ ItemID[ "ex_stoneSmall" ] , 0 , 2 , 0.1 , true ] ,
    [ VanillaItemID[ "wheat_seeds" ] , 0 , 1 , 0.7 , true ] ,
    [ VanillaItemID[ "pumpkin_seeds" ] , 0 , 1 , 0.35 , true ] ,
    [ VanillaItemID[ "melon_seeds" ] , 0 , 1 , 0.35 , true ] ,
    [ ItemID[ "ex_seedsGrass" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsOak" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "melon_seeds" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsBamboo" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsCactus" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsCanes" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_spores" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsCarrot" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsPotato" ] , 0 , 1 , 0.05 , true ] ,
    [ ItemID[ "ex_seedsBerries" ] , 0 , 1 , 0.05 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "gravel" ] , 0 , 
    [ [ VanillaItemID[ "flint" ] , 0 , 2 , 0.25 , true ] ,
    [ VanillaItemID[ "coal" ] , 0 , 1 , 0.125 , true ] ,
    [ VanillaItemID[ "lapis_lazuli" ] , 0 , 1 , 0.05 , true ] ,
    [ VanillaItemID[ "diamond" ] , 0 , 1 , 0.016 , true ] ,
    [ VanillaItemID[ "emerald" ] , 0 , 1 , 0.016 , true ] ,
    [ ItemID[ "ex_Tinbroken" ] , 0 , 1 , 0.18 , true ] ,
    [ ItemID[ "ex_Silverbroken" ] , 0 , 1 , 0.14 , true ] ,
    [ ItemID[ "ex_Leadbroken" ] , 0 , 1 , 0.15 , true ] ,
    [ ItemID[ "ex_Copperbroken" ] , 0 , 1 , 0.20 , true ] ,
    [ ItemID[ "ex_Ironbroken" ] , 0 , 1 , 0.25 , true ] ,
    [ ItemID[ "ex_Goldbroken" ] , 0 , 1 , 0.15 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 0 , 
    [ [ VanillaItemID[ "sapling" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 1 , 
    [ [ VanillaItemID[ "sapling" ] , 1 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 2 , 
    [ [ VanillaItemID[ "sapling" ] , 2 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 3 , 
    [ [ VanillaItemID[ "sapling" ] , 3 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves" ] , 4 , 
    [ [ VanillaItemID[ "sapling" ] , 4 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves2" ] , 0 , 
    [ [ VanillaItemID[ "sapling" ] , 5 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "leaves2" ] , 1 , 
    [ [ VanillaItemID[ "sapling" ] , 6 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "apple" ] , 0 , 4 , 0.2 , true ] ,
    [ VanillaItemID[ "golden_apple" ] , 0 , 1 , 0.019 , true ] ,
    [ ItemID[ "ex_silkWorm" ] , 0 , 4 , 0.16 , true ] ]
);

ExAPI.SetBlockSieveDrops( BlockID[ "ex_dust" ] , 0 , 
    [ [ VanillaItemID[ "glowstone_dust" ] , 0 , 1 , 0.07 , true ] ,
    [ VanillaItemID[ "redstone" ] , 0 , 1 , 0.25 , true ] ,
    [ VanillaItemID[ "gunpowder" ] , 0 , 1 , 0.0625 , true ] ,
    [ VanillaItemID[ "bone_meal" ] , 0 , 1 , 0.2 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "soul_sand" ] , 0 , 
    [ [ VanillaItemID[ "ghast_tear" ] , 0 , 1 , 0.02 , true ] ,
    [ VanillaItemID[ "quartz" ] , 0 , 1 , 1 , true ] ,
    [ VanillaItemID[ "quartz" ] , 0 , 1 , 0.8 , true ] ,
    [ VanillaItemID[ "soul_sand" ] , 0 , 1 , 0.1 , true ] ] 
);

ExAPI.SetBlockSieveDrops( BlockID[ "ex_gravelNether" ] , 0 , 
    [ [ ItemID[ "ex_Goldbroken" ] , 0 , 1 , 0.25 , true ] ,
    [ ItemID[ "ex_Goldbroken" ] , 0 , 1 , 0.4 , true ] ] 
);

ExAPI.SetBlockSieveDrops( VanillaBlockID[ "sand" ] , 0 , 
    [ [ VanillaItemID[ "cocoa_beans" ] , 0 , 1 , 0.03 , true ] ,
    [ ItemID[ "ex_Ironbroken" ] , 0 , 1 , 0.5 , true ] ,
    [ VanillaItemID[ "prismarine_shard" ] , 0 , 1 , 0.02 , true ]  ]
);




// file: Item/Food.js

IDRegistry.genItemID( "Green_Apple" );
Item.createFoodItem( "Green_Apple" , "Green Apple" , { name : "Green_Apple" } , { food : 2 } );

IDRegistry.genItemID( "Apple_Pie" );
Item.createFoodItem( "Apple_Pie" , "Apple_Pie" , { name : "Apple_Pie" } , { food : 7 } );

IDRegistry.genItemID( "Pine_Nut" );
Item.createFoodItem( "Pine_Nut" , "Pine Nut" , { name : "Pine_Nut" } , { food : 1 } );

Recipes.addShapeless( { id : ItemID[ "Apple_Pie" ] , count : 1 , data : 0 } , [ { id : ItemID[ "Green_Apple" ] , data : 0 } , { id : VanillaItemID[ "apple" ] , data : 0 } ] );




// file: Item/Material.js

IDRegistry.genItemID( "Iron_Stick" );
Item.createItem( "Iron_Stick" , "Iron Stick" , { name : "Iron_Stick" } );

IDRegistry.genItemID( "Motor" );
Item.createItem( "Motor" , "Motor" , { name : "Motor" } );

IDRegistry.genItemID( "Magnet_Ingot" );
Item.createItem( "Magnet_Ingot" , "Magnet Ingot" , { name : "Magnet_Ingot" } );

IDRegistry.genItemID( "Photosensitive_Element" );
Item.createItem( "Photosensitive_Element" , "Photosensitive Element" , { name : "Photosensitive_Element" } );

IDRegistry.genItemID( "Ceramics" );
Item.createItem( "Ceramics" , "Ceramics" , { name : "Ceramics" } );

IDRegistry.genItemID( "Heat_Resistant_Ceramics" );
Item.createItem( "Heat_Resistant_Ceramics" , "Heat Resistant Ceramics" , { name : "Heat_Resistant_Ceramics" } );


Recipes.addShaped( { id : ItemID[ "Iron_Stick" ] , count : 4 , data : 0 } ,
  [ "a " , " a"] ,
[ 'a' , VanillaItemID[ "iron_ingot" ] , 0 ] 
);

Recipes.addShaped( { id : ItemID[ "Magnet_Ingot" ] , count : 1 , data : 0 } ,
  [ "a " , " b"] ,
[ 'a' , VanillaItemID[ "iron_ingot" ] , 0 , "b" , ItemID[ "Iron_Stick" ] , 0 ] ,
  function ( api , result , player ) { new PlayerActor( player ).addItemToInventory( ItemID[ "Iron_Stick" ] , 1 , 0 ); } 
);

Recipes.addShaped( { id : ItemID[ "Photosensitive_Element" ] , count : 4 , data : 0 } ,
  [ " a " , "bc"] ,
[ 'a' , VanillaItemID[ "coal" ] , 0 , 'b' , ItemID[ "Ceramics" ] , 0 , 'c' , ItemID[ "ingotCopper" ] , 0 ] 
);




// file: Item/Tool.js

IDRegistry.genItemID( "Iron_Crook" );
Item.createItem( "Iron_Crook" , "Iron Crook" , { name : "Iron_Crook" } , { stack : 1 } );

IDRegistry.genItemID( "Diamond_Crook" );
Item.createItem( "Diamond_Crook" , "Diamond Crook" , { name : "Diamond_Crook" } , { stack : 1 } );

IDRegistry.genItemID( "Picking_Tool" );
Item.createItem( "Picking_Tool" , "Picking Tool" , { name : "Picking_Tool" } , { stack : 1 } );


Item.setToolRender( "Iron_Crook" , true );
Item.setToolRender( "Diamond_Crook" , true );
Item.setToolRender( "Picking_Tool" , true );

ToolAPI.registerTool( ItemID[ "Iron_Crook" ] , { durability : 250 } , [] , {
    calcDestroyTime : function ( tool , coords , block , timeData , defaultTime , enchantData ) {
        if ( block.id == VanillaTileID[ "leaves" ] || block.id == VanillaTileID[ "leaves2" ] ) return 0.2;
        return defaultTime;
    } ,
    onDestroy : function ( item , coords , block , player ) {
        if ( Game.getGameMode( ) == 1 ) {
            return false;
        }
    }
});


ToolAPI.registerTool( ItemID[ "Diamond_Crook" ] , { durability : 1561 } , [] , {
    calcDestroyTime : function ( tool , coords , block , timeData , defaultTime , enchantData ) {
        if ( block.id == VanillaTileID[ "leaves" ] || block.id == VanillaTileID[ "leaves2" ] ) return 0.2;
        return defaultTime;
    } ,
    onDestroy : function ( item , coords , block , player ) {
        if ( Game.getGameMode( ) == 1 ) {
            return false;
        }
    }
});

ToolAPI.registerTool( ItemID[ "Picking_Tool" ] , { durability : 152 } , [] , {
    calcDestroyTime : function ( tool , coords , block , timeData , defaultTime , enchantData ) {
        if ( block.id == VanillaTileID[ "leaves" ] || block.id == VanillaTileID[ "leaves2" ] ) return 0.4;
        return defaultTime;
    } ,
    onDestroy : function ( item , coords , block , player ) {
        if ( Game.getGameMode( ) == 1 ) {
            if ( block.id = 18 && block.data == ( 0 || 4 || 8 || 12 ) ) {
                Math.random() > 0.18 && World.drop( coords.x , coords.y , coords.z , ItemID[ "Pine_Nut" ] , 1 , 0 );
                Math.random() > 0.6 && World.drop( coords.x , coords.y , coords.z , ItemID[ "Green_Apple" ] , 1 , 0 );
                Math.random() > 0.75 && World.drop( coords.x , coords.y , coords.z , VanillaItemID[ "apple" ] , 1 , 0 );
            }
            return false;
        }
    }
});

ModAPI.addAPICallback( "ICore" , function ( api ) {
    IDRegistry.genItemID( "Iron_Treetap" );
    Item.createItem( "Iron_Treetap" , "Iron Treetap" , { name : "Iron_Treetap" } , { stack : 1 } );
    
    Item.setToolRender( "Iron_Treetap" , true );
    
    Item.registerUseFunction( ItemID[ "Iron_Treetap" ]  , function ( coords , item , block , player ) {
        if ( block.id == BlockID[ "rubberTreeLogLatex" ] ) {
            new PlayerActor( player ).addItemToInventory( ItemID[ "latex" ] , 1 , 0 );
        }
    } );
} );




// file: Block/Decoration.js

Block.createSpecialType( {
    base : VanillaBlockID[ "glass" ] ,
    solid : false ,
    destroytime : 0.3 ,
    explosionres : 0.3 ,
    lightopacity : 0 ,
    renderlayer : 4 ,
    translucency : 0.1 ,
    sound: "glass"
} , "CrystalGlass" );

IDRegistry.genBlockID( "Crystal_Glass" );
Block.createBlock( "Crystal_Glass" , [
    { name : "Crystal Glass" , texture : [ [ "Crystal_Glass" , 0 ] ] , inCreative : true } ,
] , "CrystalGlass" );

IDRegistry.genBlockID( "Crystal_Light_Glass " );
Block.createBlock( "Crystal_Light_Glass " , [
    { name : "Crystal Light Glass" , texture : [ [ "Crystal_Light_Glass" , 0 ] ] , inCreative : true } ,
] , Block.createSpecialType( {
    base : VanillaBlockID[ "glass" ] ,
    solid : false ,
    destroytime : 0.3 ,
    explosionres : 0.3 ,
    lightopacity : 0 ,
    lightlevel : 14 ,
    translucency : 0.1 ,
    sound: "glass"
} ) );

IDRegistry.genBlockID( "CrystalGlass_Colorful" );
Block.createBlock( "CrystalGlass_Colorful" , [
    { name : "Black Crystal Glass" , texture : [ [ "CrystalGlass_Black" , 0 ] ] , inCreative : true } ,
    { name : "Gray Crystal Glass" , texture : [ [ "CrystalGlass_Gray" , 0 ] ] , inCreative : true } ,
    { name : "Blue Crystal Glass" , texture : [ [ "CrystalGlass_Blue" , 0 ] ] , inCreative : true } ,
    { name : "Light Blue Crystal Glass" , texture : [ [ "CrystalGlass_LightBlue" , 0 ] ] , inCreative : true } ,
    { name : "Yellow Crystal Glass" , texture : [ [ "CrystalGlass_Yellow" , 0 ] ] , inCreative : true } ,
    { name : "Pink Crystal Glass" , texture : [ [ "CrystalGlass_Pink" , 0 ] ] , inCreative : true } ,
    { name : "Orange Crystal Glass" , texture : [ [ "CrystalGlass_Orange" , 0 ] ] , inCreative : true } ,
    { name : "Lime Crystal Glass" , texture : [ [ "CrystalGlass_Lime" , 0 ] ] , inCreative : true } ,
    { name : "Cyan Crystal Glass" , texture : [ [ "CrystalGlass_Cyan" , 0 ] ] , inCreative : true } ,
    { name : "Brown Crystal Glass" , texture : [ [ "CrystalGlass_Brown" , 0 ] ] , inCreative : true } ,
    { name : "Green Crystal Glass" , texture : [ [ "CrystalGlass_Green" , 0 ] ] , inCreative : true } ,
    { name : "Purple Crystal Glass" , texture : [ [ "CrystalGlass_Purple" , 0 ] ] , inCreative : true } ,
    { name : "Red Crystal Glass" , texture : [ [ "CrystalGlass_Red" , 0 ] ] , inCreative : true } ,
    { name : "White Crystal Glass" , texture : [ [ "CrystalGlass_White" , 0 ] ] , inCreative : true } ,
    { name : "Magenta Crystal Glass" , texture : [ [ "CrystalGlass_Magenta" , 0 ] ] , inCreative : true } ,
    { name : "Light Gray Crystal Glass" , texture : [ [ "CrystalGlass_LightGray" , 0 ] ] , inCreative : true } ,
] , "CrystalGlass" );

IDRegistry.genBlockID( "Light_Rod" );
Block.createBlock( "Light_Rod" , [
    { name : "Light Rod" , texture : [ [ "LightRod_top" , 0 ] , [ "LightRod_top" , 0 ] , [ "Light_Rod" , 0 ] ] , inCreative : true } ,
] , Block.createSpecialType( {
    base : VanillaBlockID[ "end_rod" ] ,
    solid : false ,
    destroytime : 0.5 ,
    explosionres : 0.4 ,
    lightopacity : 8 ,
    lightlevel : 15 ,
    translucency : 0.1 ,
    sound: "glass"
} ) );

var RodModel = new BlockRenderer.Model();
var RodICRender = new ICRender.Model();
RodModel.addBox( 11/16 , 0 , 11/16 , 5/16 , 1/16 , 5/16 , BlockID[ "Light_Rod" ] , 0 );
RodModel.addBox( 6/16 , 1/16 , 6/16 , 10/16 , 2/16 , 10/16 , BlockID[ "Light_Rod" ] , 0 );
RodModel.addBox( 7/16 , 2/16 , 7/16 , 9/16 , 13/16 , 9/16 , BlockID[ "Light_Rod" ] , 0 );
RodICRender.addEntry( RodModel );
BlockRenderer.setStaticICRender( BlockID[ "Light_Rod" ] , 0 , RodICRender );
Block.setShape( BlockID[ "Light_Rod" ] , 5/16 , 0 , 5/16 , 11/16 , 13/16 , 11/16 , 0 );



var GlassVertex = [
    [ 0 , 0 , 0 , 1/16 , 1/16 , 1/16 ] ,
    [ 0 , 0 , 1 , 1/16 , 1/16 , 15/16 ] ,
    [ 1 , 0 , 1 , 15/16 , 1/16 , 15/16 ] ,
    [ 1 , 0 , 0 , 15/16 , 1/16 , 1/16 ] ,
    [ 0 , 1 , 0 , 1/16 , 15/16 , 1/16 ] ,
    [ 0 , 1 , 1 , 1/16 , 15/16 , 15/16 ] ,
    [ 1 , 1 , 1 , 15/16 , 15/16 , 15/16 ] ,
    [ 1 , 1 , 0 , 15/16 , 15/16 , 1/16 ] 
];

var GlassEdge = [
    [ 0 , 0 , 1/16 , 1/16 , 1/16 , 15/16 ] ,
    [ 1/16 , 0 , 1/16 , 15/16 , 1/16 , 0 ] ,
    [ 15/16 , 0 , 15/16 , 1 , 1/16 , 1/16 ] ,
    [ 15/16 , 0 , 15/16 , 1/16 , 1/16 , 1 ] ,
    [ 0 , 1 , 1/16 , 1/16 , 15/16 , 15/16 ] ,
    [ 1/16 , 1 , 1/16 , 15/16 , 15/16 , 0 ] ,
    [ 15/16 , 1 , 15/16 , 1 , 15/16 , 1/16 ] ,
    [ 15/16 , 1 , 15/16 , 1/16 , 15/16 , 1 ] ,
    [ 0 , 1/16 , 0 , 1/16 , 15/16 , 1/16 ] ,
    [ 1 , 1/16 , 0 , 15/16 , 15/16 , 1/16 ] ,
    [ 1 , 1/16 , 1 , 15/16 , 15/16 , 15/16 ] ,
    [ 0 , 1/16 , 1 , 1/16 , 15/16 , 15/16 ] 
];

var GlassSide = {
    Side1 : [ 1 , 0 , 0 ] ,
    Side2 : [ 0 , 1 , 0 ] ,
    Side3 : [ 0 , 0 , 1 ] ,
    Side4 : [ -1 , 0 , 0 ] ,
    Side5 : [ 0 , -1 , 0 ] ,
    Side6 : [ 0 , 0 , -1 ] 
};

var VertexGlassAngle = {
//Layer1
    An1 : [ [ 0 , -1 , 0 ] , [ -1 , -1 , 0 ] , [ -1 , 0 , 0 ] ] ,
    An2 : [ [ 0 , -1 , 0 ] , [ 0 , -1 , 1 ] , [ 0 , 0 , 1 ] ] ,
    An3 : [ [ 0 , -1 , 0 ] , [ 1 , -1 , 0 ] , [ 1 , 0 , 0 ] ] ,
    An4 : [ [ 0 , -1 , 0 ] , [ 0 , -1 , -1 ] , [ 0 , 0 , -1 ] ] ,
//Layer2
    An5 : [ [ 0 , 0 , -1 ] , [ -1 , 0 , -1 ] , [ -1 , 0 , 0 ] ] ,
    An6 : [ [ -1 , 0 , 0 ] , [ -1 , 0 , 1 ] , [ 0 , 0 , 1 ] ] ,
    An7 : [ [ 0 , 0 , 1 ] , [ 1 , 0 , 1 ] , [ 1 , 0 , 0 ] ] ,
    An8 : [ [ 1 , 0 , 0 ] , [ 1 , 0 , -1 ] , [ 0 , 0 , -1 ] ] ,
//Layer3
    An9 : [ [ 0 , 1 , 0 ] , [ -1 , 1 , 0 ] , [ -1 , 0 , 0 ] ] ,
    An10 : [ [ 0 , 1 , 0 ] , [ 0 , 1 , 1 ] , [ 0 , 0 , 1 ] ] ,
    An11 : [ [ 0 , 1 , 0 ] , [ 1 , 1 , 0 ] , [ 1 , 0 , 0 ] ] ,
    An12 : [ [ 0 , 1 , 0 ] , [ 0 , 1 , -1 ] , [ 0 , 0 , -1 ] ] 
};

var EdgeGlassCondition = [
    { Edge : 0 , Side : [ "Side4" , "Side5" ] } ,
    { Edge : 1 , Side : [ "Side5" , "Side6" ] } ,
    { Edge : 2 , Side : [ "Side1" , "Side5" ] } ,
    { Edge : 3 , Side : [ "Side3" , "Side5" ] } ,
    { Edge : 4 , Side : [ "Side2" , "Side4" ] } ,
    { Edge : 5 , Side : [ "Side2" , "Side6" ] } ,
    { Edge : 6 , Side : [ "Side1" , "Side2" ] } ,
    { Edge : 7 , Side : [ "Side2" , "Side3" ] } ,
    { Edge : 8 , Side : [ "Side4" , "Side6" ] } ,
    { Edge : 9 , Side : [ "Side1" , "Side6" ] } ,
    { Edge : 10 , Side : [ "Side1" , "Side3" ] } ,
    { Edge : 11 , Side : [ "Side3" , "Side4" ] } 
];

var VertexGlassCondition = [
    { Ver : 0 , Angle : [ "An1" , "An5" , "An4" ] } ,
    { Ver : 1 , Angle : [ "An1" , "An6" , "An2" ] } ,
    { Ver : 2 , Angle : [ "An2" , "An7" , "An3" ] } ,
    { Ver : 3 , Angle : [ "An3" , "An8" , "An4" ] } ,
    { Ver : 4 , Angle : [ "An9" , "An5" , "An12" ] } ,
    { Ver : 5 , Angle : [ "An9" , "An6" , "An10" ] } ,
    { Ver : 6 , Angle : [ "An10" , "An7" , "An11" ] } ,
    { Ver : 7 , Angle : [ "An11" , "An8" , "An12" ] }
];

var GlassGroup = ICRender.getUnnamedGroup();

function SetGlassBeautiful ( id , data ) {
    GlassGroup.add( id , data );
    let BlockModel = new BlockRenderer.Model();
    let ICRenderModel = new ICRender.Model();
    for ( var i in EdgeGlassCondition ) {
        let edge = EdgeGlassCondition[i].Edge;
        let side = EdgeGlassCondition[i].Side;
        ICRenderModel.addEntry( new BlockRenderer.Model( GlassEdge[edge][0] , GlassEdge[edge][1] , GlassEdge[edge][2] , GlassEdge[edge][3] , GlassEdge[edge][4] , GlassEdge[edge][5] , id , data ) )
        .setCondition( new ICRender.NOT( new ICRender.OR( ICRender.BLOCK( GlassSide[side[0]][0] , GlassSide[side[0]][1] , GlassSide[side[0]][2] , GlassGroup , false ) ,
        ICRender.BLOCK( GlassSide[side[1]][0] , GlassSide[side[1]][1] , GlassSide[side[1]][2] , GlassGroup , false ) ) ) );
    };
    for ( var i in VertexGlassCondition ) {
        let ver = GlassVertex[VertexGlassCondition[i].Ver];
        let ang1 = VertexGlassAngle[VertexGlassCondition[i].Angle[0]];
        let ang2 = VertexGlassAngle[VertexGlassCondition[i].Angle[1]];
        let ang3 = VertexGlassAngle[VertexGlassCondition[i].Angle[2]];
        var C1 = new ICRender.AND( new ICRender.BLOCK( ang1[0][0] , ang1[0][1] , ang1[0][2] , GlassGroup , false ) ,
                                   new ICRender.BLOCK( ang1[1][0] , ang1[1][1] , ang1[1][2] , GlassGroup , false ) , 
                                   new ICRender.BLOCK( ang1[2][0] , ang1[2][1] , ang1[2][2] , GlassGroup , false ) );
        var C2 = new ICRender.AND( new ICRender.BLOCK( ang2[0][0] , ang2[0][1] , ang2[0][2] , GlassGroup , false ) ,
                                   new ICRender.BLOCK( ang2[1][0] , ang2[1][1] , ang2[1][2] , GlassGroup , false ) , 
                                   new ICRender.BLOCK( ang2[2][0] , ang2[2][1] , ang2[2][2] , GlassGroup , false ) );
        var C3 = new ICRender.AND( new ICRender.BLOCK( ang3[0][0] , ang3[0][1] , ang3[0][2] , GlassGroup , false ) ,
                                   new ICRender.BLOCK( ang3[1][0] , ang3[1][1] , ang3[1][2] , GlassGroup , false ) , 
                                   new ICRender.BLOCK( ang3[2][0] , ang3[2][1] , ang3[2][2] , GlassGroup , false ) );
        ICRenderModel.addEntry( new BlockRenderer.Model( ver[0] , ver[1] , ver[2] , ver[3] , ver[4] , ver[5] , id , data ) )
        .setCondition( new ICRender.AND( new ICRender.NOT( C1 ) , new ICRender.NOT( C2 ) , new ICRender.NOT( C3 ) ) );
    };
    ICRenderModel.addEntry( BlockModel );
    BlockRenderer.setStaticICRender( id , data , ICRenderModel );
};

SetGlassBeautiful( BlockID[ "Crystal_Glass" ] , 0 );
SetGlassBeautiful( BlockID[ "Crystal_Light_Glass " ] , 0 );
for ( var i = 0 ; i <= 15 ; i ++ ) {
    SetGlassBeautiful( BlockID[ "CrystalGlass_Colorful" ] , i );
}

Recipes.addShaped( { id : BlockID[ "Light_Rod" ] , count : 1 , data : 0 } ,
  [ " a" , "aba" ] , 
[ 'a' , VanillaItemID[ "glowstone_dust" ] , 0 , 'b' , VanillaItemID[ "redstone" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "Crystal_Light_Glass " ] , count : 1 , data : 0 } ,
  [ " a" , "aba" , "a" ] , 
[ 'a' , VanillaItemID[ "glowstone_dust" ] , 0 , 'b' , BlockID[ "Crystal_Glass" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 0 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "black_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 1 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "gray_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 2 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "blue_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 3 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "light_blue_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 4 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "yellow_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 4 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "yellow_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 5 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "pink_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 6 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "orange_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 7 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "lime_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 8 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "cyan_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 9 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "brown_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 10 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "green_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 11 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "purple_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 12 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "red_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 13 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "white_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 14 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "magenta_dye" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "CrystalGlass_Colorful" ] , count : 4 , data : 15 } ,
  [ " a" , "aba" , " a"] ,
[ 'a' , BlockID[ "Crystal_Glass" ] , 0 , 'b' , VanillaItemID[ "light_gray_dye" ] , 0 ] 
);

Recipes.addFurnace( VanillaBlockID[ "glass" ] , 0 , BlockID[ "Crystal_Glass" ] , 0 );

Block.registerDropFunction( BlockID[ "Crystal_Glass" ] , function ( coords , id , data , diggingLevel , enchant , item , region ) {
    if ( enchant == EEnchantment[ "UNBREAKING" ] ) return [ [ id , 1 , data ] ];
    return [];
} );

Block.registerDropFunction( BlockID[ "CrystalGlass_Colorful" ] , function ( coords , id , data , diggingLevel , enchant , item , region ) {
    if ( enchant == EEnchantment[ "UNBREAKING" ] ) return [ [ id , 1 , data ] ];
    return [];
} );

Block.registerDropFunction( BlockID[ "Crystal_Light_Glass" ] , function ( coords , id , data , diggingLevel , enchant , item , region ) {
    if ( enchant == EEnchantment[ "UNBREAKING" ] ) return [ [ id , 1 , data ] ];
    return [];
} );




// file: Block/Generator.js

IDRegistry.genBlockID( "IS_Solor" );
Block.createBlock( "IS_Solor" , [
    { name : "Solor" , texture : [ [ "Solor_buttom" , 0 ] , [ "Solor_top" , 0 ] , [ "Solor_side" , 0 ] ] , inCreative : true } 
] , "Machine" );
Block.setShape( BlockID[ "IS_Solor" ] , 0 , 0 , 0 , 1 , 1/16 , 1 , 0 );

TileEntity.registerPrototype( BlockID[ "IS_Solor" ] , {
    isEnergySource : function () {
        return true;
    } ,
    canReceiveEnergy : function () {
        return false;
    } ,
    energyTick : function( type, src ) {
        let Light_Level = new BlockSource( EDimension[ "NORMAL" ] ).getLightLevel( this.x , this.y + 1 , this.z );
        src.addAll( Math.round( Light_Level / 2 ) );
    } ,
    canExtractEnergy : function ( side, type )  {
        if ( side == EBlockSide[ "DOWN" ] ) return true;
        return false;
    }
});

EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Solor" ] , EU );


IDRegistry.genBlockID( "IS_Lava_Generator" );
Block.createBlock( "IS_Lava_Generator" , [
    { name : "Lava Generator" , texture : [ [ "Lava_Generator_side" , 0 ] , [ "Lava_Generator_top" , 0 ] , [ "Lava_Generator_side" , 0 ] ] , inCreative : true } ,
    { name : "Lava Generator" , texture : [ [ "Lava_Generator_side" , 0 ] , [ "Lava_Generator_top_anim" , 0 ] , [ "Lava_Generator_side" , 0 ] ] , inCreative : false }
] , "Machine" );

/*
var Model = new BlockRenderer.Model();
var MachineRender = new ICRender.Model();
Model.addBox( 0 , 0 , 0 , 1 , 1 , 1 , BlockID[ "IS_Lava_Generator" ] , 1 );
MachineRender.addEntry( Model );
BlockRenderer.enableCoordMapping( BlockID[ "IS_Lava_Generator" ] , 0 , MachineRender );
*/

var LavaGenerator = GetClassicUI( true );
LavaGenerator.drawing.push(
    { type : "text" , x : 300 , y : 60 , width : 230 , height : 42 , text : "Lava Generator" , font : { size : 42 , color : "#FF4F4F4F" } } 
);
LavaGenerator.elements[ "Lava_Scale_Empty" ] = { type: "image" , x : 364 , y: 75 , direction : 1 , bitmap : "Liquid_Empty_Scale" , scale : 4.5 };
LavaGenerator.elements[ "Lava_Scale" ] = { type: "scale" , x : 364 , y: 75 , direction : 1 , bitmap : "Full_Lava" , scale : 4.5 };
LavaGenerator.elements[ "Liquid_Slot" ] = { type: "slot" , x : 540 , y : 90 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { 
    if ( LiquidRegistry.getEmptyItem( id , data ) && LiquidRegistry.getEmptyItem( id , data ).liquid == "lava" ) return true;
    return false;
} };
LavaGenerator.elements[ "Empty_Slot" ] = { type: "slot" , x : 540 , y :290 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { return false } };
var Lava_UI = new UI.Window( LavaGenerator );
Lava_UI.setInventoryNeeded( true );
Lava_UI.setBlockingBackground( true );

TileEntity.registerPrototype( BlockID[ "IS_Lava_Generator" ] , {
    defaultValues : {
        "TickUse" : 0.01 ,
        "Max_Storge" : 10
    } ,
    getGuiScreen : function () {
        return Lava_UI;
    } ,
    isEnergySource : function () {
        return true;
    } ,
    canReceiveEnergy : function () {
        return false;
    } ,
    tick : function () {
        let Slot1 = this.container.getSlot( "Liquid_Slot" );
        let Slot2 = this.container.getSlot( "Empty_Slot" );
        if ( Slot1.id == 0 || this.liquidStorage.getAmount( "lava" ) > this.data.Max_Storge - 1 || Item.getMaxStack( Slot2.id ) <= Slot2.count ) return;
        let Slot1Empty = LiquidRegistry.getEmptyItem( Slot1.id , Slot1.data );
        if ( Slot1Empty == ( null || undefined ) ) return;
        if ( ( Slot1Empty.id != Slot2.id || Slot1Empty.data != Slot2.data ) && Slot2.id != 0 ) return;
        Slot1.count --;
        this.container.setSlot( "Empty_Slot" , Slot1Empty.id , Slot2.count + ( Slot1Empty.count || 1 ) , Slot1Empty.data );
        let lava_amount = this.liquidStorage.getAmount( "lava" );
        this.liquidStorage.setAmount( "lava" , lava_amount + 1 );
        this.container.validateAll();
    } ,
    energyTick : function ( type, src ) {
        let Lava_Amount = this.liquidStorage.getAmount( "lava" );
        if ( Lava_Amount >= this.data.TickUse ) {
            this.blockSource.setBlock( this.x , this.y , this.z , BlockID[ "IS_Lava_Generator" ] , 1 );
            src.addAll( 70 );
            this.liquidStorage.setAmount( "lava" , Lava_Amount - this.data.TickUse );
        } else if ( this.liquidStorage.getAmount( "lava" ) < this.data.TickUse && this.blockSource.getBlockData( this.x , this.y , this.z ) == 1 ) {
            this.blockSource.setBlock( this.x , this.y , this.z , BlockID[ "IS_Lava_Generator" ] , 0 );
        }
        this.container.setScale( "Lava_Scale" , this.liquidStorage.getAmount( "lava" ) / this.data.Max_Storge );
    } 
} );

EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Lava_Generator" ] , EU );


Recipes.addShaped( { id : BlockID[ "IS_Lava_Generator" ] , count : 1 , data : 0 } ,
  [ "aba" , "bcb" , "ada" ] ,
[ 'a' , VanillaItemID[ "iron_ingot" ] , 0 , 'b' , ItemID[ "Heat_Resistant_Ceramics" ] , 0 , 'c' , VanillaBlockID[ "furnace" ] , 0 , 'd' , VanillaItemID[ "bucket" ] , 0 ] 
);

Recipes.addShaped( { id : BlockID[ "IS_Solor" ] , count : 1 , data : 0 } ,
  [ "aaa" , "bcb" ] ,
[ 'a' , ItemID[ "Photosensitive_Element" ] , 0 , 'b' , VanillaItemID[ "iron_ingot" ] , 0 , 'c' , ItemID[ "ingotCopper" ] , 0 ] 
);




// file: Block/Electric_Sieve.js

IDRegistry.genBlockID( "IS_Electric_Sieve" );
Block.createBlock( "IS_Electric_Sieve" , [
    { name : "Electric Sieve" , texture : [ [ "Electric_Sieve_buttom" , 0 ] , [ "Electric_Sieve_top" , 0 ] , [ "Electric_Sieve_outside" , 0 ] ] , inCreative : true } ,
] , "Machine" );

/*
var Model = new BlockRenderer.Model();
var MachineRender = new ICRender.Model();
Model.addBox( 0 , 0 , 0 , 1/16 , 10/16 , 1/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
Model.addBox( 1 , 0 , 0 , 15/16 , 10/16 , 1/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
Model.addBox( 0 , 0 , 1 , 1/16 , 10/16 , 15/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
Model.addBox( 1 , 0 , 1 , 15/16 , 10/16 , 15/16 , BlockID[ "IS_Electric_Sieve" ] , 0 );
MachineRender.addEntry( Model );
BlockRenderer.setStaticICRender( BlockID[ "IS_Electric_Sieve" ] , 0  , MachineRender );
*/

var Electric_Sieve = GetClassicUI( true );
Electric_Sieve.drawing.push(
    { type : "text" , x : 360 , y : 60 , width : 230 , height : 46 , text : "Electric Sieve" , font : { size : 42 , color : "#FF4F4F4F" } } 
);
Electric_Sieve.elements[ "Empty_Rate_Scale" ] = { type: "image" , x : 390 , y : 170 , direction : 0 , bitmap : "Rate_Scale" , scale : 6.5 };
Electric_Sieve.elements[ "Rate_Scale" ] = { type: "scale" , x : 390 , y : 170 , direction : 0 , bitmap : "Rate_Scale_Full" , scale : 6.5 };
Electric_Sieve.elements[ "Input_Slot" ] = { type: "slot" , x : 215 , y : 160 , size : 125 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) {
    if ( ExAPI.GetSieveDrops( id , data ) != ( null || undefined ) ) return true;
    return false;
} };
Electric_Sieve.elements[ "Drop_Point" ] = { type: "button" , x : 240 , y :50 , scale : 3 , bitmap : "AddInside_Button" , bitmap2 : "AddInside_Button_Press" , clicker : { 
    onClick : function ( position , container , tileEntity , window , canvas , scale ) {
        var ThisObj = container.getGuiContent().elements[ "Drop_Point" ];
        if ( ThisObj.bitmap == "AddInside_Button" ) {
            ThisObj.bitmap = "AddOutside_Button";
            ThisObj.bitmap2 = "AddOutside_Button_Press";
            tileEntity.data.AddToMachine = false;
        } else {
            ThisObj.bitmap = "AddInside_Button";
            ThisObj.bitmap2 = "AddInside_Button_Press";
            tileEntity.data.AddToMachine = true;
        }
    }
} };
for ( var i = 0 ; i < 9 ; i ++ ) {
    Electric_Sieve.elements[ "Output_Slot" + i ] = { type: "slot" , x : 510 + ( i % 3 ) * 100 , y : 110 + ( i / 3 | 0 ) * 100 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { return false; } };
}
var Sieve_UI = new UI.Window( Electric_Sieve );
Sieve_UI.setInventoryNeeded( true );
Sieve_UI.setBlockingBackground( true );

ICRender.getGroup( "ic-wire" ).add( BlockID[ "IS_Electric_Sieve" ] , 0 );

TileEntity.registerPrototype( BlockID[ "IS_Electric_Sieve" ] , {
    defaultValues : {
        "AddToMachine" : true ,
        "Scale" : 0 ,
        "DropingList" : [] ,
        "FINISHIED_TIME" : 40 , 
        "ENERGY_USE" : 10 ,
        "IfEnergy" : 0
    } ,
    getGuiScreen : function () {
        return Sieve_UI;
    } ,
    CanAddItem : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( item.id != id || item.data != data ) continue;
            Count -= Item.getMaxStack( id ) - item.count;
        }
        if ( Count <= 0 ) return true;
        if ( Count > 0 ) return false;
    } ,
    AddToMachine : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( ( ( item.id != id || item.data != data ) && item.id != 0 ) || Item.getMaxStack( id ) <= item.count || Count <= 0 ) continue;
            if ( item.id != 0 && item.data != data ) continue;
            if ( Item.getMaxStack( id ) > item.count + Count ) {
                this.container.setSlot( "Output_Slot" + i , id , item.count + Count , data );
                Count = 0;
                return;
            } else {
                let a = Item.getMaxStack( id ) - item.count;
                this.container.setSlot( "Output_Slot" + i , id , item.count + a , data );
                Count -= a;
            }
        }
        if ( Count > 0 ) World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , id , Count , data );
    } ,
    energyReceive : function ( type , amount , voltage ) {
        if ( this.data.IfEnergy < this.data.ENERGY_USE && amount >= this.data.ENERGY_USE ) {
            this.data.IfEnergy += this.data.ENERGY_USE ;
            return this.data.ENERGY_USE;
        }
        return 0;
    } ,
    energyTick : function ( type , src ) {
        if ( this.data.AddToMachine == true ) {
            let SieveDrop = ExAPI.GetSieveDrops( this.container.getSlot( "Input_Slot" ).id , this.container.getSlot( "Input_Slot" ).data );
            for ( i in SieveDrop ) {
                if ( this.CanAddItem( SieveDrop , SieveDrop , 1 ) == false ) {
                    return;
                }
            }
        }
        
        let item = this.container.getSlot( "Input_Slot" );
        if ( this.data.IfEnergy >= 5 ) {
            if ( this.data.Scale > 0 ){
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
            } else if ( this.container.getSlot( "Input_Slot" ).count > 0 ) {
                item.count --;
                this.data.DropingList = ExAPI.GetFiltering( item.id , item.data );
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
            }
        }
        
        if ( this.data.Scale == this.data.FINISHIED_TIME ) {
            for ( var i in this.data.DropingList ) {
                let List = this.data.DropingList[ i ];
                if ( this.data.AddToMachine == true ) {
                    this.AddToMachine( List[0] , List[1] , List[2] );
                } else {
                    World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , List[0] , List[2] , List[1] );
                }
            }
            this.data.Scale = 0;
            this.data.DropingList = [];
            this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
        }
        this.container.validateAll();
    } ,
    canReceiveEnergy : function () { return true; }
} );
EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Electric_Sieve" ] , EU );




// file: Block/Electric_Block_Hammer.js

var Windows_Width = 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 )

IDRegistry.genBlockID( "IS_Electric_Block_Hammer" );
Block.createBlock( "IS_Electric_Block_Hammer" , [
    { name : "Electric Block Hammer" , texture : [ [ "iron_block" , 0 ] , [ "iron_block" , 0 ] , [ "iron_block" , 0 ] ] , inCreative : true } ,
] , "Machine" );

var Block_Hammer = GetClassicUI( true );
Block_Hammer.drawing.push(
    { type : "text" , x : 225 , y : 60 , width : 230 , height : 46 , text : "Electric Block Hammer" , font : { size : 42 , color : "#FF4F4F4F" } } 
);
Block_Hammer.elements[ "Rate_Scale" ] = { type : "scale" , x : 100 , y : 75 , direction : 0 , bitmap : "Rate_Scale_Full" , scale : 10 };
for ( var i = 0 ; i < 9 ; i ++ ) {
    Block_Hammer.elements[ "Output_Slot" + i ] = { type: "slot" , x : 510 + ( i % 3 ) * 100 , y : 110 + ( i / 3 | 0 ) * 100 , size : 100 , bitmap : "Classic_Slot" , iconScale : 1 , isValid : function ( id , count , data ) { return false; } };
}
var Block_Hammer_MainUI = new UI.Window( Block_Hammer );

var Block_Hammer_Input = new UI.Window( {
    location : {
        x : ( 500 - 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 ) / 2 ) - 150 * Display_Unit  ,
        y : ( 500 * ( Height / Width ) - Window_Height * ( 1 + GUI_Scale * 0.2 ) / 2 ) - 100 * Display_Unit ,
        width : Windows_Width + 150 * Display_Unit  ,
        height : 100 * Display_Unit
    } ,
    
    drawing : [
        { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
        { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 100 * Display_Unit / Windows_Width + 150 * Display_Unit , bitmap : "Classic_Frame" , scale : 3 } ,
        { type : "text" , text : "Input" , x : 2 , y : 10 , font : { size : 50 } }
    ] ,
    elements : {}
} );

var Block_Hammer_Output = new UI.Window( {
    location : {
        x : ( 500 - 1.05 * Window_Height * ( 1 + GUI_Scale * 0.2 ) / 2 ) - 150 * Display_Unit  ,
        y : Window_Height * ( 1 + GUI_Scale * 0.2 ) + Window_Height * ( 1 + GUI_Scale * 0.2 ) ,
        width : Windows_Width + 150 * Display_Unit  ,
        height : 100 * Display_Unit
    } ,
    
    drawing : [
        { type : "background" , color : android.graphics.Color.TRANSPARENT } ,
        { type : "frame" , x : 0 , y : 0 , width : 1000 , height : 100 * Display_Unit / Windows_Width + 150 * Display_Unit , bitmap : "Classic_Frame" , scale : 3 } ,
        { type : "text" , text : "Output" , x : 2 , y : 10 , font : { size : 40 } }
    ] ,
    elements : {}
} );

var Block_Hammer_UI = new UI.WindowGroup();
Block_Hammer_MainUI.setInventoryNeeded( true );
Block_Hammer_UI.addWindowInstance( "Input" , Block_Hammer_Input );
Block_Hammer_UI.addWindowInstance( "Output" , Block_Hammer_Output );
Block_Hammer_UI.addWindowInstance( "Main" , Block_Hammer_MainUI );
Block_Hammer_UI.setBlockingBackground( true );



ICRender.getGroup( "ic-wire" ).add( BlockID[ "IS_Electric_Block_Hammer" ] , 0 );

TileEntity.registerPrototype( BlockID[ "IS_Electric_Block_Hammer" ] , {
    defaultValues : {
        "AddToMachine" : true ,
        "Scale" : 0 ,
        "FINISHIED_TIME" : 40 , 
        "ENERGY_USE" : 12 ,
        "IfEnergy" : 0 ,
        "TargetSide" : 0 ,
        "TargetBlock" : []
    } ,
    getGuiScreen : function () {
        return Block_Hammer_UI;
    } ,
    CanAddItem : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( item.id != id || item.data != data ) continue;
            Count -= Item.getMaxStack( id ) - item.count;
        }
        if ( Count <= 0 ) return true;
        if ( Count > 0 ) return false;
    } ,
    AddToMachine : function ( id , data , count ) {
        let Count = count;
        for ( var i = 0 ; i < 9 ; i ++ ) {
            let item = this.container.getSlot( "Output_Slot" + i );
            if ( ( ( item.id != id || item.data != data ) && item.id != 0 ) || Item.getMaxStack( id ) <= item.count || Count <= 0 ) continue;
            if ( item.id != 0 && item.data != data ) continue;
            if ( Item.getMaxStack( id ) > item.count + Count ) {
                this.container.setSlot( "Output_Slot" + i , id , item.count + Count , data );
                Count = 0;
                return;
            } else {
                let a = Item.getMaxStack( id ) - item.count;
                this.container.setSlot( "Output_Slot" + i , id , item.count + a , data );
                Count -= a;
            }
        }
        if ( Count > 0 ) World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , id , Count , data );
    } ,
    energyReceive : function ( type , amount , voltage ) {
        if ( this.data.IfEnergy < this.data.ENERGY_USE && amount >= this.data.ENERGY_USE ) {
            this.data.IfEnergy += this.data.ENERGY_USE ;
            return this.data.ENERGY_USE;
        }
        return 0;
    } ,
    getTarget : function ( ID ) {
        return World.getBlock( this.x + Side[ID][0] , this.y + Side[ID][1] , this.z + Side[ID][2] );
    } ,
    energyTick : function ( type , src ) { 
        if ( ExAPI.GetHammerDrops( this.getTarget.id , this.getTarget.data ) == ( null || undefined ) ) { return; }
        let target = ExAPI.GetHammerDrops( this.getTarget.id , this.getTarget.data );
        if ( this.data.AddToMachine == true ) {
            if ( this.CanAddItem( target.id , target.data , target.count ) == false ) {
                return;
            }
        }
        
        if ( this.data.IfEnergy >= this.data.ENERGY_USE ) {
            if ( this.data.Scale > 0 ){
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
                if ( this.data.TargetBlock.id != target.id || this.data.TargetBlock.data != target.data ) { this.data.Scale = 0 }
            } else if ( this.data.Scale == 0 ) {
                item.count --;
                this.data.TargetBlock = [ target.id , target.data ];
                this.data.Scale ++;
                this.data.IfEnergy = 0;
                this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
            }
        }
        
        if ( this.data.Scale == this.data.FINISHIED_TIME ) {
            if ( this.data.AddToMachine == true ) {
                this.AddToMachine( target.id , target.data , target.count );
            } else {
                World.drop( this.x + 0.5 , this.y + 1.25 , this.z + 0.5 , target.id , target.count , target.data );
            }
            this.data.Scale = 0;
            this.container.setScale( "Rate_Scale" , this.data.Scale / this.data.FINISHIED_TIME );
        }
        this.container.validateAll();
    } ,
    canReceiveEnergy : function () { return true; }
} );
EnergyTileRegistry.addEnergyTypeForId( BlockID[ "IS_Electric_Block_Hammer" ] , EU );




