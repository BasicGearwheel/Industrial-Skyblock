IDRegistry.genItemID( "Green_Apple" );
Item.createFoodItem( "Green_Apple" , "Green Apple" , { name : "Green_Apple" } , { food : 2 } );

IDRegistry.genItemID( "Apple_Pie" );
Item.createFoodItem( "Apple_Pie" , "Apple_Pie" , { name : "Apple_Pie" } , { food : 7 } );

IDRegistry.genItemID( "Pine_Nut" );
Item.createFoodItem( "Pine_Nut" , "Pine Nut" , { name : "Pine_Nut" } , { food : 1 } );

Recipes.addShapeless( { id : ItemID[ "Apple_Pie" ] , count : 1 , data : 0 } , [ { id : ItemID[ "Green_Apple" ] , data : 0 } , { id : VanillaItemID[ "apple" ] , data : 0 } ] );